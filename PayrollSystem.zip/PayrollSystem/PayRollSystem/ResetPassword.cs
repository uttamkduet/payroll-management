﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace PayRollSystem
{
    public partial class ResetPassword : Form
    {
        public ResetPassword()
        {
            InitializeComponent();
        }

        private void reset_Click(object sender, EventArgs e)
        {
            if(newPass1.Text =="" || newPass2.Text == "")
            {
                errorMsg.Text = "Field must be not empty!";
            }else if (newPass1.Text != newPass2.Text)
            {
                errorMsg.Text = "Password does not match!";
            }
            else
            {
                adminGateway gatewayAdmin = new adminGateway();
                if (gatewayAdmin.ResetPassword(newPass1.Text))
                {
                    MessageBox.Show("Password Reset Successfully");
                    this.Hide();
                }
            }
        }






    }
}
