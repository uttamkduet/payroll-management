﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PayRollSystem
{
    class Category_Class
    {
        private Int32 catid;
        private string PostCategory;
        private double  BasicSalary;
        private double TravelAllowance;
        private double MedicalAllowance;
        private double RentAllowance;
        private double Bouns;
        private double other;
        private double TotalAmount;

        public int Catid { get => catid; set => catid = value; }
        public string PostCategory1 { get => PostCategory; set => PostCategory = value; }
        public double BasicSalary1 { get => BasicSalary; set => BasicSalary = value; }
        public double TravelAllowance1 { get => TravelAllowance; set => TravelAllowance = value; }
        public double MedicalAllowance1 { get => MedicalAllowance; set => MedicalAllowance = value; }
        public double RentAllowance1 { get => RentAllowance; set => RentAllowance = value; }
        public double Bouns1 { get => Bouns; set => Bouns = value; }
        public double Other { get => other; set => other = value; }
        public double TotalAmount1 { get => TotalAmount; set => TotalAmount = value; }
    }
}
