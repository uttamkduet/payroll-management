﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace PayRollSystem
{
    public partial class Z_MonthlySalary : Form
    {

        List<salaryClass> SalaryList = null;
        salaryClass classSalary = null;
        SalaryGateway gatewaySalary = null;
        public Z_MonthlySalary()
        {
            InitializeComponent();
        }

        private void Z_MonthlySalary_Load(object sender, EventArgs e)
        {
            dateTimePicker1.Format = DateTimePickerFormat.Custom;
            dateTimePicker1.CustomFormat = "MMMM yyyy";
            dateTimePicker1.ShowUpDown = true;
        }

        private void button1_Click(object sender, EventArgs e)//Search Person
        {
            string searchValue = searchbox.Text;
            int rowIndex = -1;
            bool flag = true;
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            try
            {
                foreach (DataGridViewRow row in dataGridView1.Rows)
                {
                    if (row.Cells["EmployeeCode"].Value.ToString().Contains(searchValue))
                    {
                        rowIndex = row.Index;
                        dataGridView1.ClearSelection();
                        row.Selected = true;
                        dataGridView1.FirstDisplayedScrollingRowIndex = rowIndex;
                        dataGridView1.Focus();
                        flag = false;
                        break;
                    }
                }
                if (flag == true) MessageBox.Show("No solutions with that Employee code.");
            }
            catch (Exception)
            {
                MessageBox.Show("No solutions with that Employee code.");
            }
        }

        private void button2_Click_1(object sender, EventArgs e)//Search By date
        {
            classSalary = new salaryClass();
            gatewaySalary = new SalaryGateway();
            List<salaryClass> SalaryList = new List<salaryClass>();

            classSalary.Month = dateTimePicker1.Text.ToString();
            SalaryList = gatewaySalary.GetData(classSalary);
            dataGridView1.DataSource = SalaryList;

            List<string> liststing = new List<string>();

            try
            {
                row.Text = dataGridView1.RowCount.ToString();

                liststing = gatewaySalary.getTotal(classSalary);
                rent.Text = liststing[1].ToString();
                medi.Text = liststing[4];
                travel.Text = liststing[0];
                total.Text = liststing[5];

                double bounus = double.Parse(liststing[2]);
                double others = double.Parse(liststing[3]);
                extra.Text = (bounus + others).ToString();

            }
            catch
            {
                MessageBox.Show("Somthing!!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void home_Click(object sender, EventArgs e)
        {
            Z_Dashboard dash = new Z_Dashboard();
            dash.Show();
            this.Dispose();
            this.Hide();
        }

        private void monthlyReport_Click(object sender, EventArgs e)
        {
            Z_Payslip pay = new Z_Payslip();
            pay.Show();
            this.Dispose();
            this.Hide();
        }

        private void logout_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void changePass_Click(object sender, EventArgs e)
        {
            Z_PasswordChange change = new Z_PasswordChange();
            change.Show();
            this.Dispose();
            this.Hide();
        }

        private void salary_Click(object sender, EventArgs e)
        {
            Z_MonthlySalary salary = new Z_MonthlySalary();
            salary.Show();
            this.Dispose();
            this.Hide();
        }

        private void salaryReport_Click(object sender, EventArgs e)
        {
            Z_Payroll newAddpay = new Z_Payroll();
            newAddpay.Show();
            this.Dispose();
            this.Hide();
        }

        private void addempolyee_Click(object sender, EventArgs e)
        {
            Z_add_employe employeeADD = new Z_add_employe();
            employeeADD.Show();
            this.Dispose();
            this.Hide();
        }

        private void addCategory_Click(object sender, EventArgs e)
        {
            Z_AddCategory categoryAdd = new Z_AddCategory();
            categoryAdd.Show();
            this.Dispose();
            this.Hide();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
