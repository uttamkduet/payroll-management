﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace PayRollSystem
{
    public partial class Z_EmployeeDatails : Form
    {
        public Z_EmployeeDatails()
        {
            InitializeComponent();
        }
    }
}
