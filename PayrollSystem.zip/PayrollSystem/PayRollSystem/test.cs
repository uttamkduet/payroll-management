﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PayRollSystem
{
    class test
    {
        private string catname;
        private int catid;

        public string Catname { get => catname; set => catname = value; }
        public int Catid { get => catid; set => catid = value; }
    }
}
