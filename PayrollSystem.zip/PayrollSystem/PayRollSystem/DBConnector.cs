﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Text;

namespace PayRollSystem
{
    class DBConnector
    {
        SqlConnection connection = null;

        string connectionString = @"server=DESKTOP-VB7TEQJ\SQLEXPRESS; Integrated Security=SSPI; Initial Catalog=payroll";
        //string connectionString = @"server=(local)\SQLEXPRESS; Integrated Security=SSPI; Initial Catalog=TEST";

        public SqlConnection Connection { get => connection; }
        public DBConnector()
        {
            connection = new SqlConnection(connectionString);
        }

    }
}
