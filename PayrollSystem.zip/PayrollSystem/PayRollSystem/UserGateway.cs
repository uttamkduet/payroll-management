﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Text;

namespace PayRollSystem
{
    class UserGateway
    {
        DBConnector connetor = null;
        SqlConnection connnection = null;


        public UserGateway()
        {
            connetor = new DBConnector();
            connnection = connetor.Connection;
        }


        public Boolean CheckAttendance(string date,string montYear,Int32 usrcode)
        {
            string selectQuery = "SELECT * FROM userAttendance WHERE emid = '" + usrcode + "' AND eachDay = '" + date + "'AND monthYear = '" + montYear + "' AND status = 1";

            connnection.Open();
            SqlCommand command = new SqlCommand(selectQuery, connnection);
            Int32 rows_count = Convert.ToInt32(command.ExecuteScalar());
            command.Dispose();

             connnection.Close();

            if (rows_count > 0) return false ;
             else return true;
            
           
        }

        public Boolean Attendance(string date,string montYear, Int32 usrcode)
        {
            connnection.Open();
            string insertQuery = "INSERT INTO userAttendance(emid,eachDay,monthYear,status)" +
                "VALUES('" + usrcode + "','" +date+ "','" + montYear + "','" + 1 + "')";
            SqlCommand command = new SqlCommand(insertQuery, connnection);
            command.ExecuteNonQuery();
            connnection.Close();
            return true;
        }


        public Boolean UserLoin(Int32 empcode, string pass )
        {
            string selectQuery = "SELECT * FROM employee WHERE eplyeeCode = '" + empcode + "' AND password = '" + pass + "'";

            connnection.Open();
            SqlCommand command = new SqlCommand(selectQuery, connnection);
            Int32 rows_count = Convert.ToInt32(command.ExecuteScalar());
            command.Dispose();

            connnection.Close();
            

            if (rows_count > 0) {
                UserStaticClass.Empcode = empcode;
                UserStaticClass.UserPass = pass;
                return true;
            }
            else return false;
            
        }


        public List<string> UserProfile()
        {
            List<string> Stringlist = new List<string>();
            connnection.Open();


            string selectQuery = " SELECT employee.eplyeeCode,employee.name,employee.dateTime,employee.shift,employee.email,category.catname FROM employee INNER JOIN category ON employee.postCategory = category.catid WHERE employee.eplyeeCode = '" + UserStaticClass.Empcode + "' AND employee.password = '" + UserStaticClass.UserPass + "' ";
            SqlCommand command = new SqlCommand(selectQuery, connnection);
            SqlDataReader reader = command.ExecuteReader();
            reader.Read();

            Stringlist.Add(reader[0].ToString());//eplyeeCode
            Stringlist.Add(reader[1].ToString());//name
            Stringlist.Add(reader[2].ToString());   //dateTime                          
            Stringlist.Add(reader[3].ToString());//shift
            Stringlist.Add(reader[4].ToString());//email
            Stringlist.Add(reader[5].ToString());//post



            connnection.Close();
            return Stringlist;
        }









    }
}
