﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PayRollSystem
{
    class z_shiftComboBox
    {
        string name;
        string value;

        public string Name { get => name; set => name = value; }
        public string Value { get => value; set => this.value = value; }
    }
}
