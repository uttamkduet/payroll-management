﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace PayRollSystem
{
    public partial class Dashbord2 : Form
    {
        public Dashbord2()
        {
            InitializeComponent();
        }

        private void addCategory_Click(object sender, EventArgs e)
        {

            /*Loader.Visible = true;
            Loader.Controls.Clear();
            Z_add_employe Displayaccount = new Z_add_employe();
            Displayaccount.TopLevel = false;
            Loader.Controls.Add(Displayaccount);
            Displayaccount.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            Displayaccount.Dock = DockStyle.Fill;
            Displayaccount.Show();*/
        }

        private void panel4_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel6_Paint(object sender, PaintEventArgs e)///
        {
           
        }

        private void Dashbord2_Load(object sender, EventArgs e)
        {

        }

        private void panel6_Click(object sender, EventArgs e)
        {
           
        }

        private void panel6_MouseClick(object sender, MouseEventArgs e)
        {
            Z_Dashboard data = new Z_Dashboard(1);
           
        }
    }
}
