﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace PayRollSystem
{
    public partial class Z_Dashboard : Form
    {
        public Z_Dashboard()
        {
            InitializeComponent();
           

        }
        public  Z_Dashboard(int load)
        {
            InitializeComponent();
            switch (load)
            {
                case 1:

                    //addempolyee_Click(object sender, EventArgs e)
                    break;

            }
        }

        private void home_uc1_Load(object sender, EventArgs e)
        {

        }

        public void loader()
        {

        }

        private void Z_Dashboard_Load(object sender, EventArgs e)
        {
            loderPanel.Visible = true;
            loderPanel.Controls.Clear();
            Dashbord2 PageObject = new Dashbord2();
            PageObject.TopLevel = false;
            loderPanel.Controls.Add(PageObject);
            PageObject.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            PageObject.Dock = DockStyle.Fill;
            PageObject.Show();
        }

        private void panel4_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel5_Paint(object sender, PaintEventArgs e)
        {

        }

        private void addCategory_Click(object sender, EventArgs e)//Category
        {
            loderPanel.Visible = true;

            loderPanel.Controls.Clear();
            Z_AddCategory PageObject = new Z_AddCategory();
            PageObject.TopLevel = false;
            loderPanel.Controls.Add(PageObject);
            PageObject.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            PageObject.Dock = DockStyle.Fill;
            PageObject.Show();


            addCategory.BackColor = Color.DeepSkyBlue;
            addCategory.ForeColor = Color.White;

            home.BackColor = Color.Transparent;
            home.ForeColor = Color.DeepSkyBlue;
            payslip.BackColor = Color.Transparent;
            payslip.ForeColor = Color.DeepSkyBlue;
            changePass.BackColor = Color.Transparent;
            changePass.ForeColor = Color.DeepSkyBlue;
            salary.BackColor = Color.Transparent;
            salary.ForeColor = Color.DeepSkyBlue;
            salaryReport.BackColor = Color.Transparent;
            salaryReport.ForeColor = Color.DeepSkyBlue;

            
            addempolyee.BackColor = Color.Transparent;
            addempolyee.ForeColor = Color.DeepSkyBlue; 
            emprReport.BackColor = Color.Transparent;
            emprReport.ForeColor = Color.DeepSkyBlue;


        }

        private void addempolyee_Click(object sender, EventArgs e)//Add empplyee
        {
           
            loderPanel.Visible = true;
            loderPanel.Controls.Clear();
            Z_add_employe PageObject = new Z_add_employe();
            PageObject.TopLevel = false;
            loderPanel.Controls.Add(PageObject);
            PageObject.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            PageObject.Dock = DockStyle.Fill;
            PageObject.Show();

            addempolyee.BackColor = Color.DeepSkyBlue;
            addempolyee.ForeColor = Color.White;

            addCategory.BackColor = Color.Transparent;
            addCategory.ForeColor = Color.DeepSkyBlue;
            home.BackColor = Color.Transparent;
            home.ForeColor = Color.DeepSkyBlue;
            payslip.BackColor = Color.Transparent;
            payslip.ForeColor = Color.DeepSkyBlue;
            changePass.BackColor = Color.Transparent;
            changePass.ForeColor = Color.DeepSkyBlue;
            salary.BackColor = Color.Transparent;
            salary.ForeColor = Color.DeepSkyBlue;
            salaryReport.BackColor = Color.Transparent;
            salaryReport.ForeColor = Color.DeepSkyBlue;
            emprReport.BackColor = Color.Transparent;
            emprReport.ForeColor = Color.DeepSkyBlue;




        }

        private void salaryReport_Click(object sender, EventArgs e)///payroll
        {
            
            loderPanel.Visible = true;
            loderPanel.Controls.Clear();
            Z_Payroll PageObject = new Z_Payroll();
            PageObject.TopLevel = false;
            loderPanel.Controls.Add(PageObject);
            PageObject.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            PageObject.Dock = DockStyle.Fill;
            PageObject.Show();

            salaryReport.BackColor = Color.DeepSkyBlue;
            salaryReport.ForeColor = Color.White;

            home.BackColor = Color.Transparent;
            home.ForeColor = Color.DeepSkyBlue;
            addCategory.BackColor = Color.Transparent;
            addCategory.ForeColor = Color.DeepSkyBlue;
            addempolyee.BackColor = Color.Transparent;
            addempolyee.ForeColor = Color.DeepSkyBlue;
            salary.BackColor = Color.Transparent;
            salary.ForeColor = Color.DeepSkyBlue;
            payslip.BackColor = Color.Transparent;
            payslip.ForeColor = Color.DeepSkyBlue;
            changePass.BackColor = Color.Transparent;
            changePass.ForeColor = Color.DeepSkyBlue;
            emprReport.BackColor = Color.Transparent;
            emprReport.ForeColor = Color.DeepSkyBlue;



        }

        private void salary_Click(object sender, EventArgs e)// Monthly report
        {
            
            loderPanel.Visible = true;
            loderPanel.Controls.Clear();
            Z_MonthlySalary PageObject = new Z_MonthlySalary();
            PageObject.TopLevel = false;
            loderPanel.Controls.Add(PageObject);
            PageObject.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            PageObject.Dock = DockStyle.Fill;
            PageObject.Show();


            salaryReport.BackColor = Color.Transparent;
            salaryReport.ForeColor = Color.DeepSkyBlue;

            salary.BackColor = Color.DeepSkyBlue;
            salary.ForeColor = Color.White;
            home.BackColor = Color.Transparent;
            home.ForeColor = Color.DeepSkyBlue;
            addCategory.BackColor = Color.Transparent;
            addCategory.ForeColor = Color.DeepSkyBlue;
            addempolyee.BackColor = Color.Transparent;
            addempolyee.ForeColor = Color.DeepSkyBlue; 
            payslip.BackColor = Color.Transparent;
            payslip.ForeColor = Color.DeepSkyBlue;
            changePass.BackColor = Color.Transparent;
            changePass.ForeColor = Color.DeepSkyBlue;
            emprReport.BackColor = Color.Transparent;
            emprReport.ForeColor = Color.DeepSkyBlue;

        }

        private void changePass_Click(object sender, EventArgs e)//password Change
        {
           
            loderPanel.Visible = true;
            loderPanel.Controls.Clear();
            Z_PasswordChange PageObject = new Z_PasswordChange();
            PageObject.TopLevel = false;
            loderPanel.Controls.Add(PageObject);
            PageObject.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            PageObject.Dock = DockStyle.Fill;
            PageObject.Show();


            changePass.BackColor = Color.DeepSkyBlue;
            changePass.ForeColor = Color.White;

             salary.BackColor = Color.Transparent;
            salary.ForeColor = Color.DeepSkyBlue;
            salaryReport.BackColor = Color.Transparent;
            salaryReport.ForeColor = Color.DeepSkyBlue;
            home.BackColor = Color.Transparent;
            home.ForeColor = Color.DeepSkyBlue;
            addCategory.BackColor = Color.Transparent;
            addCategory.ForeColor = Color.DeepSkyBlue;
            addempolyee.BackColor = Color.Transparent;
            addempolyee.ForeColor = Color.DeepSkyBlue;
            payslip.BackColor = Color.Transparent;
            payslip.ForeColor = Color.DeepSkyBlue;
            emprReport.BackColor = Color.Transparent;
            emprReport.ForeColor = Color.DeepSkyBlue;


        }

        private void logout_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void monthlyReport_Click(object sender, EventArgs e)///payslip
        {
            
            loderPanel.Visible = true;
            loderPanel.Controls.Clear();
            Z_Payslip PageObject = new Z_Payslip();
            PageObject.TopLevel = false;
            loderPanel.Controls.Add(PageObject);
            PageObject.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            PageObject.Dock = DockStyle.Fill;
            PageObject.Show();

            payslip.BackColor = Color.DeepSkyBlue;
            payslip.ForeColor = Color.White;

            changePass.BackColor = Color.Transparent;
            changePass.ForeColor = Color.DeepSkyBlue;
            salary.BackColor = Color.Transparent;
            salary.ForeColor = Color.DeepSkyBlue;
            salaryReport.BackColor = Color.Transparent;
            salaryReport.ForeColor = Color.DeepSkyBlue;
            home.BackColor = Color.Transparent;
            home.ForeColor = Color.DeepSkyBlue;
            addCategory.BackColor = Color.Transparent;
            addCategory.ForeColor = Color.DeepSkyBlue;
            addempolyee.BackColor = Color.Transparent;
            addempolyee.ForeColor = Color.DeepSkyBlue;
            emprReport.BackColor = Color.Transparent;
            emprReport.ForeColor = Color.DeepSkyBlue;



        }

        private void home_Click(object sender, EventArgs e)///Dashboard
        {

            loderPanel.Visible = true;
            loderPanel.Controls.Clear();
            Dashbord2 PageObject = new Dashbord2();
            PageObject.TopLevel = false;
            loderPanel.Controls.Add(PageObject);
            PageObject.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            PageObject.Dock = DockStyle.Fill;
            PageObject.Show();

            home.BackColor = Color.DeepSkyBlue;
            home.ForeColor = Color.White;

            payslip.BackColor = Color.Transparent;
            payslip.ForeColor = Color.DeepSkyBlue;
            changePass.BackColor = Color.Transparent;
            changePass.ForeColor = Color.DeepSkyBlue;
            salary.BackColor = Color.Transparent;
            salary.ForeColor = Color.DeepSkyBlue;
            salaryReport.BackColor = Color.Transparent;
            salaryReport.ForeColor = Color.DeepSkyBlue;
           
            addCategory.BackColor = Color.Transparent;
            addCategory.ForeColor = Color.DeepSkyBlue;
            addempolyee.BackColor = Color.Transparent;
            addempolyee.ForeColor = Color.DeepSkyBlue;
            emprReport.BackColor = Color.Transparent;
            emprReport.ForeColor = Color.DeepSkyBlue;

        }

        private void emprReport_Click(object sender, EventArgs e)
        {
            loderPanel.Visible = true;
            loderPanel.Controls.Clear();
            Z_EmployeeDatails PageObject = new Z_EmployeeDatails();
            PageObject.TopLevel = false;
            loderPanel.Controls.Add(PageObject);
            PageObject.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            PageObject.Dock = DockStyle.Fill;
            PageObject.Show();



            emprReport.BackColor = Color.DeepSkyBlue;
            emprReport.ForeColor = Color.White;
            home.BackColor = Color.Transparent;
            home.ForeColor = Color.DeepSkyBlue;

            payslip.BackColor = Color.Transparent;
            payslip.ForeColor = Color.DeepSkyBlue;
            changePass.BackColor = Color.Transparent;
            changePass.ForeColor = Color.DeepSkyBlue;
            salary.BackColor = Color.Transparent;
            salary.ForeColor = Color.DeepSkyBlue;
            salaryReport.BackColor = Color.Transparent;
            salaryReport.ForeColor = Color.DeepSkyBlue;

            addCategory.BackColor = Color.Transparent;
            addCategory.ForeColor = Color.DeepSkyBlue;
            addempolyee.BackColor = Color.Transparent;
            addempolyee.ForeColor = Color.DeepSkyBlue;
        }
    }
}
