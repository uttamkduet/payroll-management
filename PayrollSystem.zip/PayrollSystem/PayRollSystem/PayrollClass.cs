﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PayRollSystem
{
    class PayrollClass
    {
        private string month;
        private Int32 empid;
        private int employeeCode;
        private int postCategory;
        private string catname;
        private Int64 accountNo;
        private  int totalWorkingDays;
        private  int WorkedDays;
       
        
        private string name;

        private double BasicSalary;
        private double salary;
        private double TravelAllowance;
        private double MedicalAllowance;
        private double RentAllowance;
        private double Bouns;
        private double others;
        private string paymentMethod ;
        private double total ;
    

       
        public double BasicSalary1 { get => BasicSalary; set => BasicSalary = value; }
        public double TravelAllowance1 { get => TravelAllowance; set => TravelAllowance = value; }
        public double MedicalAllowance1 { get => MedicalAllowance; set => MedicalAllowance = value; }
        public double RentAllowance1 { get => RentAllowance; set => RentAllowance = value; }
        public double Bouns1 { get => Bouns; set => Bouns = value; }
        public double Others { get => others; set => others = value; }
       



        public int Empid { get => empid; set => empid = value; }
        public string Name { get => name; set => name = value; }
        public int EmployeeCode { get => employeeCode; set => employeeCode = value; }
        public int PostCategory { get => postCategory; set => postCategory = value; }//from
        public string Catname { get => catname; set => catname = value; }//from
  
    
       
        public int WorkedDays1 { get => WorkedDays; set => WorkedDays = value; }
        public string PaymentMethod { get => PaymentMethod1; set => PaymentMethod1 = value; }
        public int TotalWorkingDays { get => totalWorkingDays; set => totalWorkingDays = value; }
        public string PaymentMethod1 { get => paymentMethod; set => paymentMethod = value; }
        public long AccountNo { get => accountNo; set => accountNo = value; }
        public string Month { get => month; set => month = value; }
        public double Total { get => total; set => total = value; }
        public double Salary { get => salary; set => salary = value; }
    }
}
