﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Net;
using System.Net.Mail;
using System.Text;

namespace PayRollSystem
{
    class adminGateway
    {
        DBConnector connetor = null;
        SqlConnection connnection = null;

        public adminGateway()
        {
            connetor = new DBConnector();
            connnection = connetor.Connection;
        }

        public Boolean adminLoginF(string email, string passward) /// Session start
        {
            string selectQuery = "SELECT * FROM admin WHERE email = '" + email + "' AND password = '" + passward + "'";

            connnection.Open();
            SqlCommand command = new SqlCommand(selectQuery, connnection);

            Int32 rows_count = Convert.ToInt32(command.ExecuteScalar());
            command.Dispose();///previous command exit


            if (rows_count > 0)
            {
                SqlDataReader reader = command.ExecuteReader();
                reader.Read();
                adminLogin.Email = reader[1].ToString();
                adminLogin.Passworrd = reader[2].ToString();
                connnection.Close();
                return true;

            } else {
                connnection.Close();
                return false;
            }

        }


        public Boolean ChangePassword(string oldPass,string newPass){/// password change
            string selectQuery = "SELECT * FROM admin WHERE email = '" + adminLogin.Email + "' AND password = '" + oldPass + "'";

            connnection.Open();
            SqlCommand command = new SqlCommand(selectQuery, connnection);

            Int32 rows_count = Convert.ToInt32(command.ExecuteScalar());
            command.Dispose();///previous command exit
            connnection.Close();

            if (rows_count > 0)
            {
                connnection.Open();
                string updateQuery = "UPDATE admin SET password = '"+newPass+"' WHERE email = '"+ adminLogin.Email + "'";

                SqlCommand command1 = new SqlCommand(updateQuery, connnection);
                command1.ExecuteNonQuery();
                command1.Dispose();
                adminLogin.Passworrd = newPass;
                connnection.Close();
                return true;

            }
            else
            {
                return false;
            }
        }

        public Boolean checkEmail(string email)
        {
            string selectQuery = "SELECT * FROM admin WHERE email = '" + email + "'";

            connnection.Open();
            SqlCommand command = new SqlCommand(selectQuery, connnection);

            Int32 rows_count = Convert.ToInt32(command.ExecuteScalar());
            command.Dispose();///previous command exit
            connnection.Close();
            if (rows_count > 0) return true;      
           else  return false;
        }



        public Boolean sentEmail(string email)
        {
            Random rnd = new Random();
            int code = rnd.Next(1000, 15000);
            string strCode = code.ToString();

            connnection.Open();
            string updateQuery = "UPDATE admin SET random = '" + strCode + "' WHERE email = '" + email+ "'";

            SqlCommand command1 = new SqlCommand(updateQuery, connnection);
            command1.ExecuteNonQuery();

            var smtpClient = new SmtpClient("smtp.gmail.com")
            {
                Port = 587,
                Credentials = new NetworkCredential("uttam6485@gmail.com", "Uttam1625+*"),
                EnableSsl = true,
            };
           // smtpClient.Send("email", "recipient", "subject", "body");


            return true;
        }

        public Boolean VerifiedCode(string code)// For Verified code
        {
            string selectQuery = "SELECT * FROM admin WHERE email = '" + adminLogin.Email + "' AND random = '" + code + "'";

            connnection.Open();
            SqlCommand command = new SqlCommand(selectQuery, connnection);
            Int32 rows_count = Convert.ToInt32(command.ExecuteScalar());

            connnection.Close();
            if (rows_count > 0) return true;
            else return false;

        }

        public Boolean ResetPassword(string newPass)
        {
            connnection.Open();
            string updateQuery = "UPDATE admin SET password = '" + newPass + "' WHERE email = '" + adminLogin.Email + "'";

            SqlCommand command1 = new SqlCommand(updateQuery, connnection);
            command1.ExecuteNonQuery();
            connnection.Close();
            return true;
        }












    }
}
