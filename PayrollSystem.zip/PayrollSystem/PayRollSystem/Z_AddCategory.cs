﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace PayRollSystem
{
    public partial class Z_AddCategory : Form
    {

        Category_Class categoryClass = null;
        CategoryGateway categoryGateway = null;
        List<Category_Class> categoryList = null;
        int CategoryId = 0;

        public Z_AddCategory()
        {
            InitializeComponent();
        }
        private void loadList()
        {
            categoryGateway = new CategoryGateway();
            categoryList = new List<Category_Class>();
            categoryList = categoryGateway.GetAllData();
            dataGridView1.DataSource = categoryList;

        }

        private void Z_AddCategory_Load(object sender, EventArgs e)
        {
            loadList();
        }
        public Boolean ValidateFields()
        {
            Boolean isValid = true;

            var controls = new[] { postCategory, travel, medical, rent, basic,other };
            foreach (var control in controls.Where(e => String.IsNullOrWhiteSpace(e.Text)))
            {
                errorProvider1.SetError(control, "Please fill the required field");
                isValid = false;
            }
            return isValid;
        }

        public Boolean validation()
        {

            bool flag = true;
            string msg = "";
            if (postCategory.Text == "")
            {
                msg += "Designation  must be not Empty!!\n";
                flag = false;
            }
            if (basic.Text == "")
            {
                msg += "Basic Salary must be not Empty!!\n";
                flag = false;
            }
           

       
           
            if (travel.Text == "")
            {
                msg += "Travel Allowance  must be not Empty!!\n";
                flag = false;
            }
            
            if (medical.Text == "")
            {
                msg += "Medical Allowance  must be not Empty!!\n";
                flag = false;
            }

            if (bonus.Text == "")
            {
                msg += "Bounus Allowance  must be not Empty!!\n";
                flag = false;
            }
           
           

            if (rent.Text == "")
            {
                msg += "Rent Allowance  must be not Empty!!\n";
                flag = false;
            }
            if (other.Text == "")
            {
                msg += "Others Allowance  must be not Empty!!\n";
                flag = false;
            }


            if (flag == false)
            {
                MessageBox.Show(msg, "Empty", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            return true;
        }

        private void save_Click(object sender, EventArgs e)
        {
            categoryGateway = new CategoryGateway();
            categoryClass = new Category_Class();
            if (validation())
            {
                categoryClass.PostCategory1 = postCategory.Text;
                categoryClass.TravelAllowance1 = Convert.ToDouble(travel.Text);
                categoryClass.MedicalAllowance1 = double.Parse(medical.Text);
                categoryClass.Bouns1 = double.Parse(bonus.Text);
                categoryClass.RentAllowance1 = double.Parse(rent.Text);
                categoryClass.BasicSalary1 = double.Parse(basic.Text);
                categoryClass.Other = double.Parse(other.Text);

                categoryClass.TotalAmount1 = categoryClass.BasicSalary1 +
                categoryClass.BasicSalary1 * (categoryClass.TravelAllowance1 / 100) +
                categoryClass.BasicSalary1 * (categoryClass.MedicalAllowance1 / 100) +
                categoryClass.BasicSalary1 * (categoryClass.RentAllowance1 / 100) +
                categoryClass.Bouns1 + categoryClass.Other;

                categoryGateway.intsertData(categoryClass);

                MessageBox.Show("Inserted Successfull");
                loadList();
            }
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            this.CategoryId = (Int32)dataGridView1.SelectedRows[0].Cells[0].Value;
            postCategory.Text = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
            basic.Text = dataGridView1.SelectedRows[0].Cells[2].Value.ToString();
            travel.Text = dataGridView1.SelectedRows[0].Cells[3].Value.ToString();
            medical.Text = dataGridView1.SelectedRows[0].Cells[4].Value.ToString();
            rent.Text = dataGridView1.SelectedRows[0].Cells[5].Value.ToString();
            bonus.Text = dataGridView1.SelectedRows[0].Cells[6].Value.ToString();
            totalA.Text = dataGridView1.SelectedRows[0].Cells[8].Value.ToString();
        }

        private void button2_Click(object sender, EventArgs e)//Update
        {
            categoryGateway = new CategoryGateway();
            categoryClass = new Category_Class();
            if (validation())
            {
                if (this.CategoryId > 0)
                {
                    categoryClass.Catid = this.CategoryId;
                    categoryClass.PostCategory1 = postCategory.Text;
                    categoryClass.BasicSalary1 = double.Parse(basic.Text);
                    categoryClass.TravelAllowance1 = Convert.ToDouble(travel.Text);
                    categoryClass.MedicalAllowance1 = double.Parse(medical.Text);
                    categoryClass.Bouns1 = double.Parse(bonus.Text);
                    categoryClass.RentAllowance1 = double.Parse(rent.Text);

                    categoryClass.TotalAmount1 = categoryClass.BasicSalary1 +
                    categoryClass.BasicSalary1 * (categoryClass.TravelAllowance1 / 100) +
                    categoryClass.BasicSalary1 * (categoryClass.MedicalAllowance1 / 100) +
                    categoryClass.BasicSalary1 * (categoryClass.RentAllowance1 / 100) +
                    categoryClass.Bouns1 + categoryClass.Other;
                    categoryGateway.UpdateData(categoryClass);

                    MessageBox.Show("Update  Successfull", "Updated", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    loadList();
                }
                else
                {
                    MessageBox.Show("Please Select Before update !!", "Select??", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        public void ClearField()
        {
            CategoryId = 0;
            postCategory.Clear();
            basic.Clear();
            travel.Clear();
            medical.Clear();
            bonus.Clear();
            rent.Clear();
            totalA.Clear();
            other.Clear();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            ClearField();
        }

        private void button3_Click(object sender, EventArgs e)//Delete
        {
            if (this.CategoryId > 0)
            {
                DialogResult dialog = MessageBox.Show("Do You Want To Delete Category!!", "Warning!!", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                if (dialog == DialogResult.Yes)
                {
                    categoryGateway = new CategoryGateway();
                    categoryClass = new Category_Class();
                    categoryClass.Catid = this.CategoryId;
                    categoryGateway.DeleteData(categoryClass);

                    MessageBox.Show("Delete  Successfull", "Deleted", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    loadList();
                    ClearField();

                }
                else if (dialog == DialogResult.No)
                {
                    // e.Cancel = true;
                }
            }
            else
            {
                MessageBox.Show("Please Select Before Delete !!", "Select??", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void addCategory_Click(object sender, EventArgs e)
        {
            Z_AddCategory categoryAdd = new Z_AddCategory();
            categoryAdd.Show();
            this.Dispose();
            this.Hide();
        }

        private void addempolyee_Click(object sender, EventArgs e)
        {
            Z_add_employe employeeADD = new Z_add_employe();
            employeeADD.Show();
            this.Dispose();
            this.Hide();
        }

        private void salaryReport_Click(object sender, EventArgs e)
        {
            Z_Payroll newAddpay = new Z_Payroll();
            newAddpay.Show();
            this.Dispose();
            this.Hide();
        }

        private void salary_Click(object sender, EventArgs e)
        {
            Z_MonthlySalary salary = new Z_MonthlySalary();
            salary.Show();
            this.Dispose();
            this.Hide();
        }

        private void changePass_Click(object sender, EventArgs e)
        {
            Z_PasswordChange change = new Z_PasswordChange();
            change.Show();
            this.Dispose();
            this.Hide();
        }

        private void logout_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void monthlyReport_Click(object sender, EventArgs e)
        {
            Z_Payslip pay = new Z_Payslip();
            pay.Show();
            this.Dispose();
            this.Hide();
        }

        private void home_Click(object sender, EventArgs e)
        {
            Z_Dashboard dash = new Z_Dashboard();
            dash.Show();
            this.Dispose();
            this.Hide();
        }
    }
}
