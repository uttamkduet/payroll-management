﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Text;

namespace PayRollSystem
{
    class PayrollGateway
    {
        DBConnector connetor = null;
        SqlConnection connnection = null;
        List<AddEmployee> addempyList = null;
        PayrollClass classPayroll = null;



        public PayrollGateway()
        {
            connetor = new DBConnector();
            connnection = connetor.Connection;
        }




        

        public List<string> selelectrow(PayrollClass classPayroll)
        {
            List<string> Stringlist = new List<string>();
            connnection.Open();
            //string selectQuery = "SELECT * FROM employee where empid = 18";
                                                                                                                                                      
            string selectQuery = "SELECT employee.empid,employee.name,employee.eplyeeCode,employee.account,employee.email,category.catid,category.catname,category.basicSalary,category.travelAll,category.mediAll,category.rent,category.bonus,category.others FROM employee INNER JOIN category ON " +
                "employee.postCategory = category.catid WHERE employee.eplyeeCode = '"+ classPayroll.EmployeeCode + "' ";

            SqlCommand command = new SqlCommand(selectQuery, connnection);
            SqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                
                Stringlist.Add(reader["eplyeeCode"].ToString());//0
                Stringlist.Add(reader["name"].ToString());//1
                Stringlist.Add(reader["catname"].ToString());//2
                Stringlist.Add(reader["account"].ToString());//3
                Stringlist.Add(reader["basicSalary"].ToString());//4
                Stringlist.Add(reader["travelAll"].ToString());//5
                Stringlist.Add(reader["mediAll"].ToString());//6
                Stringlist.Add(reader["rent"].ToString());//7
                Stringlist.Add(reader["bonus"].ToString());//8
                Stringlist.Add(reader["others"].ToString());//8



               /* Stringlist.Add(reader.GetValue(0).ToString());*/

            }

            connnection.Close();
            return Stringlist;
        }

        public void InsertPayslip(PayrollClass classPayroll)
        {

            
            connnection.Open();
            string insertQuery = "INSERT INTO payslip(empcode,name,postCategory,account,T_working,date,basicSalary,p_working,salary,travel,rent,bonus,other,total,medical,method)" +
                "VALUES('" + classPayroll.EmployeeCode + "','" + classPayroll.Name + "','" + classPayroll.Catname + "','" + classPayroll.AccountNo + "','" + classPayroll.TotalWorkingDays + "','" + classPayroll.Month + "','" + classPayroll.BasicSalary1 + "','" + classPayroll.WorkedDays1 + "','" + classPayroll.Salary + "','" + classPayroll.TravelAllowance1  + "','" + classPayroll.RentAllowance1  + "','" + classPayroll.Bouns1 + "','"+ classPayroll.Others+ "','" + classPayroll.Total + "','" + classPayroll.MedicalAllowance1 + "','" + classPayroll.PaymentMethod+ "')";
            SqlCommand command = new SqlCommand(insertQuery, connnection);
            command.ExecuteNonQuery();
            connnection.Close();
        }

        public List<string> GetTotalAttendance(PayrollClass classPayroll)
        {
            List<string> Stringlist = new List<string>();
            connnection.Open();

            string ss = "January 2021";
            int dd = 10003;
            string selectQuery = "SELECT  SUM(present) FROM userAttendance where emid = '" + classPayroll.EmployeeCode + "' AND monthYear = '"+ classPayroll.Month + "'";
    

            SqlCommand command = new SqlCommand(selectQuery, connnection);
            SqlDataReader reader = command.ExecuteReader();
            reader.Read();
         
            Stringlist.Add(reader[0].ToString());//0
           


            connnection.Close();
            return Stringlist;
           
        }












    }
}
