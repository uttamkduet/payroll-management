﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace PayRollSystem
{
    public partial class Z_UserAttendance : Form
    {
        

        UserGateway gatewayuser = null;
        public Z_UserAttendance()
        {
            InitializeComponent();
            timer1.Start();
            this.datetime.Enabled = false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string AllDate = datetime.Text;
            string date = AllDate.Substring(0, 2);
            string montYear = AllDate.Substring(3, 12);
            gatewayuser = new UserGateway();
             if(gatewayuser.CheckAttendance(date, montYear, UserStaticClass.Empcode)){
    
                if(gatewayuser.Attendance(date, montYear, UserStaticClass.Empcode))
                {
                    MessageBox.Show("Success");
                }
            }else  MessageBox.Show("Allready Done");

        }

        private void Z_UserAttendance_Load(object sender, EventArgs e)
        {
            datetime.Format = DateTimePickerFormat.Custom;
            datetime.CustomFormat = "dd MMMM yyyy";
            datetime.ShowUpDown = true;

            
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            

            DateTime datetime =  DateTime.Now;
          
            //this.TimerShow.Text = datetime.ToString(@"dd\.hh\:mm\:ss");
            this.TimerShow.Text = datetime.ToString(@"hh\:mm\:ss");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Z_UserProfile profile = new Z_UserProfile();
            profile.Show();
        }
    }
}
