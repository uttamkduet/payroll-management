﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace PayRollSystem
{
    public partial class Z_Payroll : Form
    {

        PayrollClass classPayroll = null;
        PayrollGateway gateWayPayroll = null;
        List<string> liststing = null;

        public Z_Payroll()
        {
            InitializeComponent();
        }

        private void Z_Payroll_Load(object sender, EventArgs e)
        {
            month.Format = DateTimePickerFormat.Custom;
            month.CustomFormat = "MMMM yyyy";
            month.ShowUpDown = true;
        }

        private void FieldLoad()
        {
            if (presentDays.Text != "0")
            {
                double BasicSalary = double.Parse(basic.Text);
                double medical = double.Parse(medi.Text);
                double Travel = double.Parse(travel.Text);
                double Rent = double.Parse(rent.Text);
                double Bonus = double.Parse(bouns.Text);
                double Others = double.Parse(bouns.Text);
                double Salary = double.Parse(salaryI.Text);
                double Total = Salary + medical + Travel + Rent + Bonus + Others;
                total.Text = Total.ToString();
            }
           
        }
        public void FieldClear()
        {
            basic.Clear();
            travel.Clear();
            rent.Clear();
            medi.Clear();
            others.Clear();
            bouns.Clear();
            total.Clear();
        }

        private void button1_Click(object sender, EventArgs e)//search Button
        {
            FieldClear();


            classPayroll = new PayrollClass();
            gateWayPayroll = new PayrollGateway();
            liststing = new List<string>();

           


            try
            {
                ///For Total Attendance
                classPayroll.EmployeeCode = Int32.Parse(empcode.Text);
                classPayroll.Month = month.Text;
                List<string> Stringlist = new List<string>();
                Stringlist = gateWayPayroll.GetTotalAttendance(classPayroll);
                if (Stringlist[0] == "") presentDays.Text = "0";
                else presentDays.Text = Stringlist[0];

                //For Geting value
                    double Travel, Rent, Medi, Basic;
                    
                    liststing = gateWayPayroll.selelectrow(classPayroll);
                
                    empcode.Text = liststing[0].ToString();
                    empname.Text = liststing[1];
                    empcategory.Text = liststing[2];
                    account.Text = liststing[3];
            
                if (presentDays.Text !="0" )
                {
                    basic.Text = liststing[4];
                    Basic = double.Parse(liststing[4]);
                    Travel = double.Parse(liststing[5]);
                    Rent = double.Parse(liststing[7]);
                    Medi = double.Parse(liststing[6]);

                    travel.Text = ((Travel / 100) * Basic).ToString();
                    medi.Text = ((Medi / 100) * Basic).ToString();
                    rent.Text = ((Rent / 100) * Basic).ToString(); ;
                    bouns.Text = liststing[8];
                    others.Text = liststing[9];
                }
                
              }
            catch
             {
                 MessageBox.Show("Input is incorrect!!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
             }

        }

        private void totalwork_TextChanged(object sender, EventArgs e)
        {
            if (totalwork.Text != "")
            {
                double perday = double.Parse(basic.Text) / double.Parse(totalwork.Text);
                double Salary = perday * double.Parse(presentDays.Text);
                salaryI.Text = Salary.ToString();
            }
            if (salaryI.Text != "") FieldLoad();
        }

        private void button3_Click(object sender, EventArgs e)//Insert into slip
        {
            gateWayPayroll = new PayrollGateway();
            if (totalwork.Text == "")
            {
                MessageBox.Show("Enter Total Working Day!!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (presentDays.Text != "0")
            {
                if (cash.Checked == true || online.Checked == true)
                {
                    classPayroll = new PayrollClass();
                    classPayroll.EmployeeCode = int.Parse(empcode.Text);
                    classPayroll.Name = empname.Text;
                    classPayroll.Catname = empcategory.Text;
                    classPayroll.AccountNo = Int64.Parse(account.Text);
                    classPayroll.Month = month.Text;
                    classPayroll.TotalWorkingDays = int.Parse(totalwork.Text);
                    classPayroll.WorkedDays1 = int.Parse(presentDays.Text);
                    classPayroll.Salary = double.Parse(salaryI.Text);
                    classPayroll.BasicSalary1 = double.Parse(basic.Text);
                    classPayroll.TravelAllowance1 = double.Parse(travel.Text);
                    classPayroll.MedicalAllowance1 = double.Parse(medi.Text);
                    classPayroll.RentAllowance1 = double.Parse(rent.Text);
                    classPayroll.Bouns1 = double.Parse(bouns.Text);
                    classPayroll.Others = double.Parse(others.Text);
                    classPayroll.Total = double.Parse(total.Text);

                    if (cash.Checked == true) classPayroll.PaymentMethod = cash.Text;
                    if (online.Checked == true) classPayroll.PaymentMethod = online.Text;
                    gateWayPayroll.InsertPayslip(classPayroll);
                    MessageBox.Show("Inserted Successfull");
                }
                else MessageBox.Show("Please Select Payment Method!!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else MessageBox.Show("Present days are null!!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);


        }



       










        private void addCategory_Click(object sender, EventArgs e)
        {
            Z_AddCategory categoryAdd = new Z_AddCategory();
            categoryAdd.Show();
            this.Dispose();
            this.Hide();
        }

        private void addempolyee_Click(object sender, EventArgs e)
        {
            Z_add_employe newAddEmplye = new Z_add_employe();
            newAddEmplye.Show();
            this.Dispose();
            this.Hide();
        }

        private void salaryReport_Click(object sender, EventArgs e)
        {
            Z_Payroll newAddpay = new Z_Payroll();
            newAddpay.Show();
            this.Dispose();
            this.Hide();
        }

        private void salary_Click(object sender, EventArgs e)
        {
            Z_MonthlySalary salary = new Z_MonthlySalary();
            salary.Show();
            this.Dispose();
            this.Hide();
        }

        private void changePass_Click(object sender, EventArgs e)
        {
            Z_PasswordChange change = new Z_PasswordChange();
            change.Show();
            this.Dispose();
            this.Hide();
        }

        private void logout_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void monthlyReport_Click(object sender, EventArgs e)
        {
            Z_Payslip pay = new Z_Payslip();
            pay.Show();
            this.Dispose();
            this.Hide();
        }

        private void home_Click(object sender, EventArgs e)
        {
            Z_Dashboard dash = new Z_Dashboard();
            dash.Show();
            this.Dispose();
            this.Hide();
        }

       
    }
}
