﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace PayRollSystem
{
    public partial class ForgatePassword : Form
    {
        public ForgatePassword()
        {
            InitializeComponent();
        }

        private void ForgatePassword_Load(object sender, EventArgs e)
        {
            panel2.Visible = false;
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            adminGateway gatewayAdmin = new adminGateway();

            if (email.Text == "")
            {
                errorMsg.Text = "Field Must be not empty!";
                return;
            }
            else
            {
                if (gatewayAdmin.checkEmail(email.Text))
                {
                    adminLogin.Email = email.Text;
                    gatewayAdmin.sentEmail(email.Text);
                    success.Text = "Sent Code,cheack '"+ email.Text + "'";
                    panel1.Visible = false;
                    panel2.Visible = true;
                    //panel2.Location(192,45);

                }
                else errorMsg.Text = "Email did not find !";

            }
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)/// verified email
        {
            adminGateway gatewayAdmin = new adminGateway();
            
           if (gatewayAdmin.VerifiedCode(codevefied.Text))
            {
                MessageBox.Show("yes");
                this.Hide();
                ResetPassword  rp = new ResetPassword();
                rp.Show();
            }


        }
    }
}
