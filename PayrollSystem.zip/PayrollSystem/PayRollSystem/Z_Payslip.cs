﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace PayRollSystem
{
    public partial class Z_Payslip : Form
    {

        List<salaryClass> SalaryList = null;
        salaryClass classSalary = null;
        SalaryGateway gatewaySalary = null;
        int EmpCode = 0;
        public Z_Payslip()
        {
            InitializeComponent();
        }

        private void Z_Payslip_Load(object sender, EventArgs e)
        {
            dateTimePicker1.Format = DateTimePickerFormat.Custom;
            dateTimePicker1.CustomFormat = "MMMM yyyy";
            dateTimePicker1.ShowUpDown = true;
        }

        private void button2_Click(object sender, EventArgs e)// Search by date
        {
            classSalary = new salaryClass();
            gatewaySalary = new SalaryGateway();
            List<salaryClass> SalaryList = new List<salaryClass>();

            classSalary.Month = dateTimePicker1.Text.ToString();
            SalaryList = gatewaySalary.GetData(classSalary);
            dataGridView1.DataSource = SalaryList;

         
            this.EmpCode = (Int32)dataGridView1.SelectedRows[0].Cells["EmployeeCode"].Value;

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string searchValue = searchbox.Text;
            int rowIndex = -1;
            bool flag = true;
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            try
            {
                foreach (DataGridViewRow row in dataGridView1.Rows)
                {
                    if (row.Cells["EmployeeCode"].Value.ToString().Contains(searchValue))
                    {
                        rowIndex = row.Index;
                        dataGridView1.ClearSelection();
                        row.Selected = true;
                        dataGridView1.FirstDisplayedScrollingRowIndex = rowIndex;
                        dataGridView1.Focus();
                        flag = false;
                        break;
                    }
                }
                if (flag == true) MessageBox.Show("No solutions with that Employee code.");
            }
            catch (Exception)
            {
                MessageBox.Show("No solutions with that Employee code.");
            }
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            this.EmpCode = (Int32)dataGridView1.SelectedRows[0].Cells["EmployeeCode"].Value;
            //MessageBox.Show(CategoryId.ToString());
        }

        private void payslip_Click(object sender, EventArgs e)
        {
            if (EmpCode > 0)
            {
                Z_PrintView k = new Z_PrintView(EmpCode);
                k.ShowDialog();
            }
            else
            {
                MessageBox.Show("Please Select Before Print !!", "Select??", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            
        }

        private void home_Click(object sender, EventArgs e)
        {

        }

        private void addCategory_Click(object sender, EventArgs e)
        {
            Z_AddCategory categoryAdd = new Z_AddCategory();
            categoryAdd.Show();
            this.Dispose();
            this.Hide();
        }

        private void addempolyee_Click(object sender, EventArgs e)
        {
            Z_add_employe newAddEmplye = new Z_add_employe();
            newAddEmplye.Show();
            this.Dispose();
            this.Hide();
        }

        private void emprReport_Click(object sender, EventArgs e)
        {

        }

        private void salary_Click(object sender, EventArgs e)
        {
            Z_MonthlySalary salary = new Z_MonthlySalary();
            salary.Show();
            this.Dispose();
            this.Hide();
        }

        private void salaryReport_Click(object sender, EventArgs e)
        {
            Z_Payroll newAddpay = new Z_Payroll();
            newAddpay.Show();
            this.Dispose();
            this.Hide();
        }

        private void changePass_Click(object sender, EventArgs e)
        {
            Z_PasswordChange change = new Z_PasswordChange();
            change.Show();
            this.Dispose();
            this.Hide();
        }

        private void logout_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void monthlyReport_Click(object sender, EventArgs e)
        {
            Z_Payslip pay = new Z_Payslip();
            pay.Show();
            this.Dispose();
            this.Hide();
        }
    }
}
