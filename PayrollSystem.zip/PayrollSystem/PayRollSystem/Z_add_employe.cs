﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace PayRollSystem
{
    public partial class Z_add_employe : Form
    {

        AddEmployee EmployeeAdd = null;
        addEmlyGateway GatewayaddEmployee = null;
        CategoryGateway categoryGateway = null;
        List<AddEmployee> EpolyeeList = null;
        int emlyid = 0;



        public Z_add_employe()
        {
            InitializeComponent();
        }


        private void Z_add_employe_Load(object sender, EventArgs e)
        {
            loadviewList();
            shift_combobox();
            Status_combobox();


           



            //Show category list in combobox
            BindingList<test> _comboItems = new BindingList<test>();
            CategoryGateway categoryGateway = new CategoryGateway();
            _comboItems = categoryGateway.GetAllData2();
            postCategory.ValueMember = "Catid";
            postCategory.DisplayMember = "Catname";
            postCategory.DataSource = _comboItems;

        }

        private void loadviewList()
        {
            //grid view
            addEmlyGateway GatewayaddEmployee = new addEmlyGateway();
            List<AddEmployee> EpolyeeList = new List<AddEmployee>();
            EpolyeeList = GatewayaddEmployee.GetData();
            dataGridView1.DataSource = EpolyeeList;

            this.dataGridView1.Columns["Empid"].Visible = false;
            this.dataGridView1.Columns["PostCategory"].Visible = false;
            this.dataGridView1.Columns["Password"].Visible = false;
            
        }
        private void shift_combobox()
        {
            List<z_shiftComboBox> list = new List<z_shiftComboBox>();
            list.Add(new z_shiftComboBox() { Value = "Select", Name = "Select" });
            list.Add(new z_shiftComboBox() { Value = "Day", Name = "Day" });
            list.Add(new z_shiftComboBox() { Value = "Night", Name = "Night" });
            shift.DataSource = list;
            shift.ValueMember = "Value";
            shift.DisplayMember = "Name";
            shift.SelectedIndex = 0;
        }

        private void Status_combobox()
        {
            List<z_shiftComboBox> list = new List<z_shiftComboBox>();
            list.Add(new z_shiftComboBox() { Value = "Select", Name = "Select" });
            list.Add(new z_shiftComboBox() { Value = "Active", Name = "Active" });
            list.Add(new z_shiftComboBox() { Value = "Inactive", Name = "Inactive" });
            status.DataSource = list;
            status.ValueMember = "Value";
            status.DisplayMember = "Name";
            status.SelectedIndex = 0;
        }


        private Boolean Validation()
        {
            bool flag = true;
            string msg = "";
            if (employeeCode.Text == "")
            {
                msg += "Employee Code must be not Empty!!\n";
                flag = false;
            }
            if (name.Text == ""){
                msg += "Name Code must be not Empty!!\n";
                flag = false;
            }
           /* if (birthday.Text == "")
            {
                msg += " Birthday must be not Empty!!\n";
                flag = false;
            }*/
            
                if (postCategory.SelectedValue.ToString() == "Select")
            {
                msg += "The Designation must be not Selected !!\n";
                flag = false;
            }
            if (shift.SelectedValue.ToString() == "Select")
            {
                msg += "The Shift must be not Selected !!\n";
                flag = false;
            }
            if (address.Text == "")
            {
                msg += "Adress Code must be not Empty!!\n";
                flag = false;
            }
            if (mobnumber.Text == "")
            {
                msg += "Mobile Number  must be not Empty!!\n";
                flag = false;
            }
            if (account.Text == "")
            {
                msg += "Account  must be not Empty!!\n";
                flag = false;
            }

            if (email.Text == "")
            {
                msg += "Email  must be not Empty!!\n";
                flag = false;
            }
            if (status.SelectedValue.ToString() == "Select")
            {
                msg += " The Status must be not Empty!!\n";
                flag = false;
            }
           /* if (Hired.Text == "")
            {
                msg += " Hired date must be not Empty!!\n";
                flag = false;
            }*/
           
            if (password.Text == "")
            {
                msg += "Passward  must be not Empty!!\n";
                flag = false;
            }

            if (flag == false)
            {
                MessageBox.Show(msg, "Empty", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            return true;
        }

        private void button1_Click(object sender, EventArgs e)///Insert Data
        {
            AddEmployee EmployeeAdd = new AddEmployee();
            addEmlyGateway GatewayaddEmployee = new addEmlyGateway();


           // string theDate = birthday.Value.ToShortDateString();
           // string theDate2 = hired.Value.ToShortDateString();


            if (Validation())
            {

                EmployeeAdd.Name = name.Text;
                EmployeeAdd.BirthDay = birth.Text;
                EmployeeAdd.EmployeeCode = int.Parse(employeeCode.Text);

                string test = "0" + postCategory.SelectedValue;
                int postid = Convert.ToInt32(test);

                EmployeeAdd.PostCategory = postid;
                EmployeeAdd.Address = address.Text;
                EmployeeAdd.MobNumber = Convert.ToInt32(mobnumber.Text);
                EmployeeAdd.AccountNumber = Convert.ToInt32(account.Text);
                EmployeeAdd.Email = email.Text;
                string test1 = "0" + status.GetItemText(status.SelectedItem);
                EmployeeAdd.Status = status.SelectedValue.ToString();
                EmployeeAdd.Password = password.Text;
                EmployeeAdd.HiredDate1 = hired.Text;
                EmployeeAdd.Shift1 = shift.SelectedValue.ToString();


                if (GatewayaddEmployee.intsertData(EmployeeAdd))
                {
                    loadviewList();
                    MessageBox.Show("Inserted Successfull");
                }else MessageBox.Show("Allready This Employee Code Exits", "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void ClearField()
        {
            employeeCode.Clear();
            name.Clear();
            address.Clear();
            mobnumber.Clear();
            account.Clear();
            email.Clear();
            employeeCode.ReadOnly = false;
            password.ReadOnly = false;
            this.emlyid = 0;

        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)//select and view to field
        {
            employeeCode.Text = dataGridView1.SelectedRows[0].Cells["EmployeeCode"].Value.ToString();
            //or s name.Text =  dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
            name.Text = dataGridView1.SelectedRows[0].Cells["name"].Value.ToString();

            string ss = dataGridView1.SelectedRows[0].Cells["PostCategory"].Value.ToString();
            emlyid = int.Parse(dataGridView1.SelectedRows[0].Cells["Empid"].Value.ToString());

            ///selected Category in comboBox
            for (int i = 0; i < postCategory.Items.Count; i++)
            {
                var prop = postCategory.Items[i].GetType().GetProperty(postCategory.ValueMember);
                if (prop != null && prop.GetValue(postCategory.Items[i], null).ToString() == ss)
                {
                    postCategory.SelectedIndex = i;
                    break;
                }
            }

            string date = dataGridView1.SelectedRows[0].Cells[3].Value.ToString();
            // DateTime birthday = Convert.ToDateTime(date);
            address.Text = dataGridView1.SelectedRows[0].Cells["Address"].Value.ToString();
            mobnumber.Text = dataGridView1.SelectedRows[0].Cells["MobNumber"].Value.ToString();
            account.Text = dataGridView1.SelectedRows[0].Cells["AccountNumber"].Value.ToString();
            email.Text = dataGridView1.SelectedRows[0].Cells["Email"].Value.ToString();
            birth.Text = dataGridView1.SelectedRows[0].Cells["BirthDay"].Value.ToString();
            hired.Text = dataGridView1.SelectedRows[0].Cells["HiredDate1"].Value.ToString();
           


            string sshift = dataGridView1.SelectedRows[0].Cells["Shift1"].Value.ToString();
            ///selected Shift in comboBox
            for (int i = 0; i < shift.Items.Count; i++)
            {
                var prop = shift.Items[i].GetType().GetProperty(shift.DisplayMember);
                if (prop != null && prop.GetValue(shift.Items[i], null).ToString() == sshift)
                {
                    shift.SelectedIndex = i;
                    break;
                }
            }

            string status1 = dataGridView1.SelectedRows[0].Cells["Status"].Value.ToString();
            ///selected Shift in comboBox
            for (int i = 0; i < shift.Items.Count; i++)
            {
                var prop = status.Items[i].GetType().GetProperty(status.DisplayMember);
                if (prop != null && prop.GetValue(status.Items[i], null).ToString() == status1)
                {
                    status.SelectedIndex = i;
                    break;
                }
            }


            employeeCode.ReadOnly = true;
            password.ReadOnly = true;
            //status.Text =  dataGridView1.SelectedRows[0].Cells[8].Value.ToString();
            //hired.Text =  dataGridView1
        }

        private void button2_Click(object sender, EventArgs e) // Update
        {
            AddEmployee EmployeeAdd = new AddEmployee();
            addEmlyGateway GatewayaddEmployee = new addEmlyGateway();


            

            if (this.emlyid > 0)
            {
                if (Validation())
                {
                    EmployeeAdd.Empid = this.emlyid;

                    EmployeeAdd.Name = name.Text;
                    EmployeeAdd.BirthDay = birth.Text;

                    string test = "0" + postCategory.SelectedValue;
                    int postid = Convert.ToInt32(test);

                    EmployeeAdd.PostCategory = postid;
                    EmployeeAdd.EmployeeCode = int.Parse(employeeCode.Text);
                    EmployeeAdd.Address = address.Text;
                    EmployeeAdd.MobNumber = int.Parse(mobnumber.Text);
                    EmployeeAdd.AccountNumber = int.Parse(account.Text);
                    EmployeeAdd.Email = email.Text;

                    EmployeeAdd.Status = status.SelectedValue.ToString();
                    EmployeeAdd.Password = password.Text;
                    EmployeeAdd.HiredDate1 = hired.Text;
                    EmployeeAdd.Shift1 = shift.SelectedValue.ToString();


                    GatewayaddEmployee.updateData(EmployeeAdd);
                    loadviewList();
                    MessageBox.Show("Update  Successfull", "Updated", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            else MessageBox.Show("Please Select Item Before Update !!", "Updae??", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        private void button4_Click(object sender, EventArgs e)//cleaer
        {
            ClearField();
        }

        private void delete_Click(object sender, EventArgs e)
        {
            if (this.emlyid > 0)
            {
                DialogResult dialog = MessageBox.Show("Do You Want To Delete Emplyee!!", "Warning!!", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                if (dialog == DialogResult.Yes)
                {
                    AddEmployee EmployeeAdd = new AddEmployee();
                    addEmlyGateway GatewayaddEmployee = new addEmlyGateway();
                    EmployeeAdd.Empid = this.emlyid;
                    GatewayaddEmployee.DeleteById(EmployeeAdd);

                    MessageBox.Show("Delete  Successfull", "Deleted", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    loadviewList();
                    ClearField();

                }
                else if (dialog == DialogResult.No)
                {
                    // e.Cancel = true;
                }
            }
            else
            {
                MessageBox.Show("Please Select Before Delete !!", "Select??", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void search_Click(object sender, EventArgs e)/// Search Value
        {
            string searchValue = searchField.Text;
            int rowIndex = -1;
            bool flag = true;
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            try
            {
                foreach (DataGridViewRow row in dataGridView1.Rows)
                {
                    if (row.Cells["EmployeeCode"].Value.ToString().Contains(searchValue))
                    {
                        rowIndex = row.Index;
                        dataGridView1.ClearSelection();
                        row.Selected = true;
                        dataGridView1.FirstDisplayedScrollingRowIndex = rowIndex;
                        dataGridView1.Focus();
                        flag = false;
                        break;
                    }
                }
                if (flag == true) MessageBox.Show("No solutions with that Employee code.");
            }
            catch (Exception)
            {
                MessageBox.Show("No solutions with that Employee code.");
            }
        }

        private void home_Click(object sender, EventArgs e)
        {
            Z_Dashboard dash = new Z_Dashboard();
            dash.Show();
            this.Dispose();
            this.Hide();
        }

        private void monthlyReport_Click(object sender, EventArgs e)
        {
            Z_Payslip pay = new Z_Payslip();
            pay.Show();
            this.Dispose();
            this.Hide();
        }

        private void logout_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void changePass_Click(object sender, EventArgs e)
        {
            Z_PasswordChange change = new Z_PasswordChange();
            change.Show();
            this.Dispose();
            this.Hide();
        }

        private void salary_Click(object sender, EventArgs e)
        {
            Z_MonthlySalary salary = new Z_MonthlySalary();
            salary.Show();
            this.Dispose();
            this.Hide();
        }

        private void salaryReport_Click(object sender, EventArgs e)
        {
            Z_Payroll newAddpay = new Z_Payroll();
            newAddpay.Show();
            this.Dispose();
            this.Hide();
        }

        private void addempolyee_Click(object sender, EventArgs e)
        {
            Z_add_employe employeeADD = new Z_add_employe();
            employeeADD.Show();
            this.Dispose();
            this.Hide();
        }

        private void addCategory_Click(object sender, EventArgs e)
        {
            Z_AddCategory categoryAdd = new Z_AddCategory();
            categoryAdd.Show();
            this.Dispose();
            this.Hide();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
