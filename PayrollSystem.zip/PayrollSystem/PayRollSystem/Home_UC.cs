﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace PayRollSystem
{
    public partial class Home_UC : UserControl
    {
        public Home_UC()
        {
            InitializeComponent();
           
        }

        private void Home_UC_Load(object sender, EventArgs e)
        {

        }

        private void panel10_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
