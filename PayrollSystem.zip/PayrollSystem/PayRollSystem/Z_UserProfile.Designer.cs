﻿
namespace PayRollSystem
{
    partial class Z_UserProfile
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.name = new System.Windows.Forms.Label();
            this.post = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.empCode = new System.Windows.Forms.Label();
            this.name1 = new System.Windows.Forms.Label();
            this.post1 = new System.Windows.Forms.Label();
            this.birth = new System.Windows.Forms.Label();
            this.shift = new System.Windows.Forms.Label();
            this.email = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 22F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(46, 44);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(257, 41);
            this.label1.TabIndex = 0;
            this.label1.Text = "Employee Profile";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(46, 116);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(121, 21);
            this.label2.TabIndex = 4;
            this.label2.Text = "Employee Code:";
            // 
            // name
            // 
            this.name.AutoSize = true;
            this.name.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.name.Location = new System.Drawing.Point(112, 146);
            this.name.Name = "name";
            this.name.Size = new System.Drawing.Size(55, 21);
            this.name.TabIndex = 5;
            this.name.Text = "Name:";
            // 
            // post
            // 
            this.post.AutoSize = true;
            this.post.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.post.Location = new System.Drawing.Point(71, 178);
            this.post.Name = "post";
            this.post.Size = new System.Drawing.Size(96, 21);
            this.post.TabIndex = 6;
            this.post.Text = "Designation:";
            this.post.Click += new System.EventHandler(this.label4_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label5.Location = new System.Drawing.Point(67, 210);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(100, 21);
            this.label5.TabIndex = 7;
            this.label5.Text = "Date of Birth:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label6.Location = new System.Drawing.Point(122, 242);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(45, 21);
            this.label6.TabIndex = 8;
            this.label6.Text = "Shift:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label7.Location = new System.Drawing.Point(116, 277);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(51, 21);
            this.label7.TabIndex = 9;
            this.label7.Text = "Email:";
            // 
            // empCode
            // 
            this.empCode.AutoSize = true;
            this.empCode.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.empCode.Location = new System.Drawing.Point(195, 122);
            this.empCode.Name = "empCode";
            this.empCode.Size = new System.Drawing.Size(50, 20);
            this.empCode.TabIndex = 10;
            this.empCode.Text = "label8";
            // 
            // name1
            // 
            this.name1.AutoSize = true;
            this.name1.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.name1.Location = new System.Drawing.Point(195, 152);
            this.name1.Name = "name1";
            this.name1.Size = new System.Drawing.Size(50, 20);
            this.name1.TabIndex = 11;
            this.name1.Text = "label8";
            // 
            // post1
            // 
            this.post1.AutoSize = true;
            this.post1.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.post1.Location = new System.Drawing.Point(195, 184);
            this.post1.Name = "post1";
            this.post1.Size = new System.Drawing.Size(50, 20);
            this.post1.TabIndex = 12;
            this.post1.Text = "label8";
            // 
            // birth
            // 
            this.birth.AutoSize = true;
            this.birth.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.birth.Location = new System.Drawing.Point(195, 216);
            this.birth.Name = "birth";
            this.birth.Size = new System.Drawing.Size(50, 20);
            this.birth.TabIndex = 13;
            this.birth.Text = "label8";
            // 
            // shift
            // 
            this.shift.AutoSize = true;
            this.shift.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.shift.Location = new System.Drawing.Point(195, 248);
            this.shift.Name = "shift";
            this.shift.Size = new System.Drawing.Size(50, 20);
            this.shift.TabIndex = 14;
            this.shift.Text = "label8";
            // 
            // email
            // 
            this.email.AutoSize = true;
            this.email.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.email.Location = new System.Drawing.Point(195, 283);
            this.email.Name = "email";
            this.email.Size = new System.Drawing.Size(50, 20);
            this.email.TabIndex = 15;
            this.email.Text = "label8";
            // 
            // Z_UserProfile
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(395, 450);
            this.Controls.Add(this.email);
            this.Controls.Add(this.shift);
            this.Controls.Add(this.birth);
            this.Controls.Add(this.post1);
            this.Controls.Add(this.name1);
            this.Controls.Add(this.empCode);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.post);
            this.Controls.Add(this.name);
            this.Controls.Add(this.label2);
            this.Name = "Z_UserProfile";
            this.Text = "Profile";
            this.Load += new System.EventHandler(this.Z_UserProfile_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label name;
        private System.Windows.Forms.Label post;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label empCode;
        private System.Windows.Forms.Label name1;
        private System.Windows.Forms.Label post1;
        private System.Windows.Forms.Label birth;
        private System.Windows.Forms.Label shift;
        private System.Windows.Forms.Label email;
    }
}