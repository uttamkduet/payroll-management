﻿
namespace PayRollSystem
{
    partial class Attend_login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.AttenL = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.textemail = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.textpass = new System.Windows.Forms.TextBox();
            this.Attenlogin = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.errorMsg = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // AttenL
            // 
            this.AttenL.AutoSize = true;
            this.AttenL.Font = new System.Drawing.Font("Kozuka Gothic Pr6N B", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.AttenL.ForeColor = System.Drawing.Color.PapayaWhip;
            this.AttenL.Location = new System.Drawing.Point(94, 21);
            this.AttenL.Name = "AttenL";
            this.AttenL.Size = new System.Drawing.Size(382, 68);
            this.AttenL.TabIndex = 0;
            this.AttenL.Text = "ATTENDANCE LOG IN";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.ForeColor = System.Drawing.Color.OrangeRed;
            this.label1.Location = new System.Drawing.Point(47, 132);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(129, 21);
            this.label1.TabIndex = 1;
            this.label1.Text = "Employee Code";
            // 
            // textemail
            // 
            this.textemail.Location = new System.Drawing.Point(195, 124);
            this.textemail.Name = "textemail";
            this.textemail.Size = new System.Drawing.Size(221, 29);
            this.textemail.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label2.ForeColor = System.Drawing.Color.OrangeRed;
            this.label2.Location = new System.Drawing.Point(94, 189);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(82, 21);
            this.label2.TabIndex = 3;
            this.label2.Text = "Password";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // textpass
            // 
            this.textpass.Location = new System.Drawing.Point(196, 181);
            this.textpass.Name = "textpass";
            this.textpass.PasswordChar = '*';
            this.textpass.Size = new System.Drawing.Size(220, 29);
            this.textpass.TabIndex = 4;
            // 
            // Attenlogin
            // 
            this.Attenlogin.ForeColor = System.Drawing.Color.Crimson;
            this.Attenlogin.Location = new System.Drawing.Point(196, 240);
            this.Attenlogin.Name = "Attenlogin";
            this.Attenlogin.Size = new System.Drawing.Size(110, 38);
            this.Attenlogin.TabIndex = 5;
            this.Attenlogin.Text = "Log in";
            this.Attenlogin.UseVisualStyleBackColor = true;
            this.Attenlogin.Click += new System.EventHandler(this.Attenlogin_Click);
            // 
            // button2
            // 
            this.button2.ForeColor = System.Drawing.Color.Crimson;
            this.button2.Location = new System.Drawing.Point(331, 240);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(85, 38);
            this.button2.TabIndex = 6;
            this.button2.Text = "Exit";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // errorMsg
            // 
            this.errorMsg.AutoSize = true;
            this.errorMsg.Location = new System.Drawing.Point(196, 89);
            this.errorMsg.Name = "errorMsg";
            this.errorMsg.Size = new System.Drawing.Size(0, 21);
            this.errorMsg.TabIndex = 7;
            // 
            // Attend_login
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 21F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkTurquoise;
            this.ClientSize = new System.Drawing.Size(556, 382);
            this.Controls.Add(this.errorMsg);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.Attenlogin);
            this.Controls.Add(this.textpass);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textemail);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.AttenL);
            this.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.ForeColor = System.Drawing.Color.OrangeRed;
            this.Name = "Attend_login";
            this.Text = "Attendlog in";
            this.Load += new System.EventHandler(this.Attend_login_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label AttenL;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textemail;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button Attenlogin;
        private System.Windows.Forms.TextBox textpass;
        private System.Windows.Forms.Label errorMsg;
    }
}