﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace PayRollSystem
{
    public partial class Z_PrintView : Form
    {
        Int32 EmplyCode = 0;
        
        SalaryGateway gatewaySalary = null;

        public Z_PrintView(Int32 emcode )
        {
            this.EmplyCode = emcode;
            InitializeComponent();
            getBill();
        }

        public void getBill()
        {
             gatewaySalary = new SalaryGateway();
            List<string> liststing = new List<string>();
            liststing = gatewaySalary.getBillPrint(EmplyCode);
            empcode.Text = liststing[0];
            name.Text = liststing[1];
            catPost.Text = liststing[2];
            basicSalay.Text = liststing[6];
            presentDay.Text = liststing[7];
            working.Text = liststing[4];
            method.Text = liststing[13];
            salary.Text = liststing[8];
            medi.Text = liststing[16];
            travel.Text = liststing[9];
            rent.Text = liststing[10];
            bonus.Text = liststing[11];
            other.Text = liststing[12];
            total.Text = liststing[15];
            month.Text = liststing[5];
           
            
            

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void Z_PrintView_Load(object sender, EventArgs e)
        {

        }

        Bitmap bp;
        private void button1_Click(object sender, EventArgs e)
        {
            Graphics g = CreateGraphics();
            bp = new Bitmap(this.Size.Width, this.Size.Height, g);
            Graphics mg = Graphics.FromImage(bp);
            mg.CopyFromScreen(this.Location.X, this.Location.Y, 0, 0, this.Size);
            printPreviewDialog1.ShowDialog();
        }
    }
}
