﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data.SqlClient;
using System.Text;

namespace PayRollSystem
{
    class CategoryGateway
    {
        DBConnector connetor = null;
        SqlConnection connnection = null;
        List<Category_Class> categoryList = null;
        Category_Class categoryClass= null;
        test otest = null;


        public CategoryGateway()
        {
            connetor = new DBConnector();
            connnection = connetor.Connection;
        }

        public void intsertData(Category_Class catClass)
        {
            connnection.Open();
            string insertQuery = "INSERT INTO category(catname,basicSalary,travelAll,mediAll,rent,bonus,total)" +
                "VALUES('"+ catClass.PostCategory1 + "','"+ catClass.BasicSalary1 + "','" + catClass.TravelAllowance1 + "','" + catClass.MedicalAllowance1 + "','" + catClass.RentAllowance1 + "','" + catClass.Bouns1 + "','" + catClass.TotalAmount1 + "')";
            SqlCommand command = new SqlCommand(insertQuery, connnection);
            command.ExecuteNonQuery();
            connnection.Close();
        }

        public List<Category_Class> GetAllData()
        {
            connnection.Open();
            categoryList = new List<Category_Class>();
            string selectQuery = "SELECT * FROM category";
            SqlCommand command = new SqlCommand(selectQuery, connnection);
            SqlDataReader reader = command.ExecuteReader();

            while (reader.Read()){
                categoryClass = new Category_Class();

               categoryClass.Catid = Convert.ToInt32( reader["catid"]);
                categoryClass.PostCategory1 = reader["catname"].ToString();
                categoryClass.BasicSalary1 = Convert.ToDouble(reader["basicSalary"]);
                categoryClass.TravelAllowance1 = Convert.ToDouble(reader["travelAll"]);
                categoryClass.MedicalAllowance1 = Convert.ToDouble(reader["mediAll"]);
                categoryClass.RentAllowance1 = Convert.ToDouble(reader["rent"]);
                categoryClass.Bouns1 = Convert.ToDouble(reader["bonus"]);
                categoryClass.TotalAmount1 = Convert.ToDouble(reader["total"]);
                categoryList.Add(categoryClass); 
            }
       
            connnection.Close();
            return categoryList;
        }

        public void UpdateData(Category_Class catClass)
        {
            connnection.Open();
            string updateQuery = "UPDATE category SET " +
                "catname = '" + catClass.PostCategory1 + "'," +
                "basicSalary = '" + catClass.BasicSalary1 + "'," +
                 "travelAll = '" + catClass.TravelAllowance1 + "'," +
                 "mediAll = '" + catClass.MedicalAllowance1 + "'," +
                "rent = '" + catClass.RentAllowance1 + "'," +
                 "bonus = '" + catClass.Bouns1 + "'," +
                "total = '" + catClass.TotalAmount1 + "' WHERE catid = '" + catClass.Catid + "'";

            SqlCommand command = new SqlCommand(updateQuery, connnection);
            command.ExecuteNonQuery();
            connnection.Close();
        }


        public void DeleteData(Category_Class catClass)
        {
            connnection.Open();
            string updateQuery = "DELETE FROM category WHERE catid = '" + catClass.Catid + "'";

            SqlCommand command = new SqlCommand(updateQuery, connnection);
            command.ExecuteNonQuery();
            connnection.Close();
        }


        public BindingList<test> GetAllData2()
        {

            connnection.Open();
            BindingList<test> _comboItems = new BindingList<test>();
            
            string selectQuery = "SELECT * FROM category";
            SqlCommand command = new SqlCommand(selectQuery, connnection);
            SqlDataReader reader = command.ExecuteReader();

            while (reader.Read())
            {
                otest = new test();

                otest.Catname = reader["catname"].ToString();
                otest.Catid = Convert.ToInt32(reader["catid"]);

                _comboItems.Add(otest);
              //  _comboItems.Add(new test { Catname = reader["catname"].ToString(), Catid = Convert.ToInt32(reader["catid"]) });
            }

            connnection.Close();
            return _comboItems;
        }










    }
}
