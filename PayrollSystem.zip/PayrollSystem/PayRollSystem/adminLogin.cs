﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Text;
using System.Text.RegularExpressions;

namespace PayRollSystem
{
   public static class adminLogin{

        
        static string email;
        static string passworrd;

        public static string Email { get => email; set => email = value; }
        public static string Passworrd { get => passworrd; set => passworrd = value; }

        public static bool IsEmail(this string email)
        {
            string partern = @"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$";
            if (Regex.IsMatch(email, partern)){
                return true;
            }
            else return false;
        }










    }
}
