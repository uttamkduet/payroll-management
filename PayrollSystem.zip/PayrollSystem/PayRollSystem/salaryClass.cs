﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PayRollSystem
{
    class salaryClass
    {

        private string month;
        private string name;
        private int employeeCode;
        private string catname;
        private Int64 accountNo;
        private int totalWorkingDays;
        private int WorkedDays;


        private double BasicSalary;
        private double salary;
        private double travelAllowance;
        private double medicalAllowance;
        private double rentAllowance;
        private double bouns;
        private double others;
        private double total;
        private string paymentMethod;

        public string Month { get => month; set => month = value; }
        public string Name { get => name; set => name = value; }
        public int EmployeeCode { get => employeeCode; set => employeeCode = value; }
        public string Catname { get => catname; set => catname = value; }
        public long AccountNo { get => accountNo; set => accountNo = value; }
        public int TotalWorkingDays { get => TotalWorkingDays1; set => TotalWorkingDays1 = value; }
        public int TotalWorkingDays1 { get => totalWorkingDays; set => totalWorkingDays = value; }
        public int WorkedDays1 { get => WorkedDays; set => WorkedDays = value; }
        public double BasicSalary1 { get => BasicSalary; set => BasicSalary = value; }
        public double Salary { get => salary; set => salary = value; }
       
        public double TravelAllowance { get => travelAllowance; set => travelAllowance = value; }
        public double MedicalAllowance { get => medicalAllowance; set => medicalAllowance = value; }
        public double RentAllowance { get => rentAllowance; set => rentAllowance = value; }
        public double Bouns { get => bouns; set => bouns = value; }
        public double Others { get => others; set => others = value; }
        public double Total { get => total; set => total = value; }
        public string PaymentMethod { get => paymentMethod; set => paymentMethod = value; }
    }
}
