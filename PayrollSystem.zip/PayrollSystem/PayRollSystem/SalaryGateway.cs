﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Text;

namespace PayRollSystem
{
    class SalaryGateway
    {

        DBConnector connetor = null;
        SqlConnection connnection = null;
        List<salaryClass> salaryList = null;
        salaryClass classSalary = null;



        public SalaryGateway()
        {
            connetor = new DBConnector();
            connnection = connetor.Connection;
        }



        public List<salaryClass> GetData(salaryClass classSalary)
        {
            connnection.Open();
            salaryList = new List<salaryClass>();


            string selectQuery = " SELECT * FROM payslip WHERE date= '"+classSalary.Month+"' ";
            //try {
            SqlCommand command = new SqlCommand(selectQuery, connnection);
            SqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                classSalary = new salaryClass();

                
                classSalary.EmployeeCode = Convert.ToInt32(reader["empcode"]);
                classSalary.Name = reader["name"].ToString();
                classSalary.Catname = reader["postCategory"].ToString();      //from categroy table                           
                classSalary.Month = reader["date"].ToString();
                classSalary.TotalWorkingDays = Convert.ToInt32(reader["T_working"].ToString());
                classSalary.WorkedDays1 =  Convert.ToInt32(reader["p_working"]);
                classSalary.AccountNo = Convert.ToInt32(reader["account"]);
                classSalary.BasicSalary1 = Convert.ToDouble(reader["basicSalary"]);
                classSalary.Salary = Convert.ToDouble(reader["salary"]);
                classSalary.TravelAllowance = Convert.ToDouble(reader["travel"]);
                classSalary.MedicalAllowance = Convert.ToDouble(reader["medical"]);
                classSalary.RentAllowance = Convert.ToDouble(reader["rent"]);
                classSalary.Bouns = Convert.ToDouble(reader["bonus"].ToString());
                classSalary.Others = Convert.ToDouble(reader["other"].ToString());
                classSalary.Total = Convert.ToDouble(reader["total"].ToString());
                classSalary.PaymentMethod = reader["method"].ToString();

                salaryList.Add(classSalary);
            }
            connnection.Close();
            return salaryList;
            /*  } catch {
                  return addempyList;
              }*/

        }

        public List<string> getTotal(salaryClass classSalary)
        {
            List<string> Stringlist = new List<string>();
            connnection.Open();
 
            string selectQuery = "SELECT  SUM(travel), SUM(rent),SUM(bonus),SUM(other),SUM(medical),SUM(total) FROM payslip where date = '"+ classSalary.Month+ "'";

           
            SqlCommand command = new SqlCommand(selectQuery, connnection);
            SqlDataReader reader = command.ExecuteReader();
            reader.Read();

                Stringlist.Add(reader[0].ToString());//0
                Stringlist.Add(reader[1].ToString());//0
                Stringlist.Add(reader[2].ToString());//0
                Stringlist.Add(reader[3].ToString());//0
                Stringlist.Add(reader[4].ToString());//0
                Stringlist.Add(reader[5].ToString());//0
                
           
            connnection.Close();
            return Stringlist;
        }

        public List<string> getBillPrint(Int32 cpmId)
        {
            List<string> Stringlist = new List<string>();
            connnection.Open();


            string selectQuery = " SELECT * FROM payslip WHERE empcode = '" + cpmId + "' ";
            SqlCommand command = new SqlCommand(selectQuery, connnection);
            SqlDataReader reader = command.ExecuteReader();
            reader.Read();

            Stringlist.Add(reader[0].ToString());//empcode
            Stringlist.Add(reader[1].ToString());//name
            Stringlist.Add(reader[2].ToString());   //fr categroy                          
            Stringlist.Add(reader[3].ToString());//account
            Stringlist.Add(reader[4].ToString());//total working
            Stringlist.Add(reader[5].ToString());//date 
            Stringlist.Add(reader[6].ToString());//basic salary
            Stringlist.Add(reader[7].ToString());//pre working
            Stringlist.Add(reader[8].ToString());//salary
            Stringlist.Add(reader[9].ToString());//travel
            Stringlist.Add(reader[10].ToString());//rent 
            Stringlist.Add(reader[11].ToString());//bounus
            Stringlist.Add(reader[12].ToString());//other
            Stringlist.Add(reader[13].ToString());//method
            Stringlist.Add(reader[14].ToString());//id
            Stringlist.Add(reader[15].ToString());//total
            Stringlist.Add(reader[16].ToString());//total



            connnection.Close();
            return Stringlist;
        }














    }
}
