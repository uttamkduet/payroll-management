﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace PayRollSystem
{
    public partial class passwordChange : UserControl
    {
        public passwordChange()
        {
            InitializeComponent();
        }

        private void change_Click(object sender, EventArgs e)
        {
            if (oldPass.Text=="" || newPass1.Text == "" || newPass2.Text == "")
            {
                errorMsg.Text = "Field Must be not Empty";
            }else if (newPass1.Text != newPass2.Text)
            {
                errorMsg.Text = "New Password does not match!";
            }
            else
            {
                adminGateway gatewayAdmin = new adminGateway();
                if (gatewayAdmin.ChangePassword(oldPass.Text, newPass1.Text))
                {
                    errorMsg.Text = "successfully Change Password!";
                }
                else
                {
                    errorMsg.Text = "Old password does not match!";
                }
               
            }
        }

        private void passwordChange_Load(object sender, EventArgs e)
        {

        }
    }
}
