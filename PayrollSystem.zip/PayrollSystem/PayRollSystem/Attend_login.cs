﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;

using System.Windows.Forms;

namespace PayRollSystem
{
    public partial class Attend_login : Form
    {
        UserGateway gatewayuser = null; 
        public Attend_login()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void Attend_login_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void Attenlogin_Click(object sender, EventArgs e) 
        {
            gatewayuser = new UserGateway();
            if(textemail.Text=="" || textpass.Text == "")
            {
                errorMsg.Text = "Field must be not Empty!";
            }
            else
            {
                if (gatewayuser.UserLoin(Convert.ToInt32(textemail.Text), textpass.Text))
                {
                    Z_UserAttendance attendance = new Z_UserAttendance();
                    attendance.Show();
                    this.Hide();
                }else errorMsg.Text = "Employee Code and Password does not match !";

            }
                

        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
