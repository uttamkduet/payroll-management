﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace PayRollSystem
{
    public partial class Emplyee_report : UserControl
    {
        public Emplyee_report()
        {
            InitializeComponent();
        }

        private void Emplyee_report_Load(object sender, EventArgs e)
        {

        }
    }
}
