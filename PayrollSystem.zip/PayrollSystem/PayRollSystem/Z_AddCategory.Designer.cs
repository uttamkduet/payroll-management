﻿
namespace PayRollSystem
{
    partial class Z_AddCategory
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label4 = new System.Windows.Forms.Label();
            this.postCategory = new System.Windows.Forms.TextBox();
            this.travelfds = new System.Windows.Forms.Label();
            this.totalA = new System.Windows.Forms.TextBox();
            this.bo = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.save = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.panel5 = new System.Windows.Forms.Panel();
            this.total = new System.Windows.Forms.Label();
            this.medical = new System.Windows.Forms.TextBox();
            this.other = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.bonus = new System.Windows.Forms.TextBox();
            this.medi = new System.Windows.Forms.Label();
            this.rent = new System.Windows.Forms.TextBox();
            this.travel = new System.Windows.Forms.TextBox();
            this.basic = new System.Windows.Forms.TextBox();
            this.basicSalary = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.SuspendLayout();
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label4.ForeColor = System.Drawing.Color.DarkOrange;
            this.label4.Location = new System.Drawing.Point(451, 130);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(69, 18);
            this.label4.TabIndex = 119;
            this.label4.Text = "Others :";
            // 
            // postCategory
            // 
            this.postCategory.Location = new System.Drawing.Point(169, 49);
            this.postCategory.Margin = new System.Windows.Forms.Padding(4);
            this.postCategory.Name = "postCategory";
            this.postCategory.Size = new System.Drawing.Size(135, 27);
            this.postCategory.TabIndex = 118;
            this.postCategory.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // travelfds
            // 
            this.travelfds.AutoSize = true;
            this.travelfds.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.travelfds.ForeColor = System.Drawing.Color.DarkOrange;
            this.travelfds.Location = new System.Drawing.Point(20, 123);
            this.travelfds.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.travelfds.Name = "travelfds";
            this.travelfds.Size = new System.Drawing.Size(145, 18);
            this.travelfds.TabIndex = 117;
            this.travelfds.Text = "Travel Allowance :";
            // 
            // totalA
            // 
            this.totalA.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.totalA.Location = new System.Drawing.Point(520, 167);
            this.totalA.Margin = new System.Windows.Forms.Padding(4);
            this.totalA.Name = "totalA";
            this.totalA.ReadOnly = true;
            this.totalA.Size = new System.Drawing.Size(135, 24);
            this.totalA.TabIndex = 116;
            this.totalA.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // bo
            // 
            this.bo.AutoSize = true;
            this.bo.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.bo.ForeColor = System.Drawing.Color.DarkOrange;
            this.bo.Location = new System.Drawing.Point(446, 91);
            this.bo.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.bo.Name = "bo";
            this.bo.Size = new System.Drawing.Size(75, 18);
            this.bo.TabIndex = 115;
            this.bo.Text = "Bounus :";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.panel4.Controls.Add(this.label1);
            this.panel4.Location = new System.Drawing.Point(223, 3);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(256, 35);
            this.panel4.TabIndex = 114;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(46, 3);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(161, 24);
            this.label1.TabIndex = 21;
            this.label1.Text = "Category Details";
            // 
            // button4
            // 
            this.button4.FlatAppearance.BorderColor = System.Drawing.Color.DarkOrange;
            this.button4.FlatAppearance.BorderSize = 2;
            this.button4.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Chocolate;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.button4.ForeColor = System.Drawing.Color.DarkOrange;
            this.button4.Location = new System.Drawing.Point(508, 219);
            this.button4.Margin = new System.Windows.Forms.Padding(4);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(76, 30);
            this.button4.TabIndex = 113;
            this.button4.Text = "Clear";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button3
            // 
            this.button3.FlatAppearance.BorderColor = System.Drawing.Color.Red;
            this.button3.FlatAppearance.BorderSize = 2;
            this.button3.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.button3.ForeColor = System.Drawing.Color.Red;
            this.button3.Location = new System.Drawing.Point(403, 219);
            this.button3.Margin = new System.Windows.Forms.Padding(4);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(76, 30);
            this.button3.TabIndex = 112;
            this.button3.Text = "Delete";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button2
            // 
            this.button2.FlatAppearance.BorderColor = System.Drawing.Color.Green;
            this.button2.FlatAppearance.BorderSize = 2;
            this.button2.FlatAppearance.MouseDownBackColor = System.Drawing.Color.LightGreen;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.button2.ForeColor = System.Drawing.Color.Green;
            this.button2.Location = new System.Drawing.Point(303, 219);
            this.button2.Margin = new System.Windows.Forms.Padding(4);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(76, 30);
            this.button2.TabIndex = 111;
            this.button2.Text = "Update";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // save
            // 
            this.save.FlatAppearance.BorderColor = System.Drawing.Color.DarkOrange;
            this.save.FlatAppearance.BorderSize = 2;
            this.save.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Chocolate;
            this.save.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.save.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.save.ForeColor = System.Drawing.Color.DarkOrange;
            this.save.Location = new System.Drawing.Point(200, 219);
            this.save.Margin = new System.Windows.Forms.Padding(4);
            this.save.Name = "save";
            this.save.Size = new System.Drawing.Size(76, 30);
            this.save.TabIndex = 110;
            this.save.Text = "Save";
            this.save.UseVisualStyleBackColor = true;
            this.save.Click += new System.EventHandler(this.save_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(2, 282);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(4);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowTemplate.Height = 25;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(730, 221);
            this.dataGridView1.TabIndex = 109;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.DarkOrange;
            this.panel5.Location = new System.Drawing.Point(8, 270);
            this.panel5.Margin = new System.Windows.Forms.Padding(4);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(730, 3);
            this.panel5.TabIndex = 108;
            // 
            // total
            // 
            this.total.AutoSize = true;
            this.total.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.total.ForeColor = System.Drawing.Color.DarkOrange;
            this.total.Location = new System.Drawing.Point(405, 169);
            this.total.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.total.Name = "total";
            this.total.Size = new System.Drawing.Size(118, 18);
            this.total.TabIndex = 107;
            this.total.Text = "Total Amount :";
            // 
            // medical
            // 
            this.medical.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.medical.Location = new System.Drawing.Point(169, 160);
            this.medical.Margin = new System.Windows.Forms.Padding(4);
            this.medical.Name = "medical";
            this.medical.PlaceholderText = "%";
            this.medical.Size = new System.Drawing.Size(135, 24);
            this.medical.TabIndex = 106;
            this.medical.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // other
            // 
            this.other.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.other.Location = new System.Drawing.Point(519, 126);
            this.other.Margin = new System.Windows.Forms.Padding(4);
            this.other.Name = "other";
            this.other.Size = new System.Drawing.Size(135, 24);
            this.other.TabIndex = 105;
            this.other.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label7.ForeColor = System.Drawing.Color.DarkOrange;
            this.label7.Location = new System.Drawing.Point(381, 52);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(134, 18);
            this.label7.TabIndex = 104;
            this.label7.Text = "Rent Allowance :";
            // 
            // bonus
            // 
            this.bonus.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.bonus.Location = new System.Drawing.Point(519, 89);
            this.bonus.Margin = new System.Windows.Forms.Padding(4);
            this.bonus.Name = "bonus";
            this.bonus.Size = new System.Drawing.Size(135, 24);
            this.bonus.TabIndex = 103;
            this.bonus.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // medi
            // 
            this.medi.AutoSize = true;
            this.medi.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.medi.ForeColor = System.Drawing.Color.DarkOrange;
            this.medi.Location = new System.Drawing.Point(1, 164);
            this.medi.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.medi.Name = "medi";
            this.medi.Size = new System.Drawing.Size(157, 18);
            this.medi.TabIndex = 102;
            this.medi.Text = "Medical Allowance :";
            // 
            // rent
            // 
            this.rent.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.rent.Location = new System.Drawing.Point(518, 50);
            this.rent.Margin = new System.Windows.Forms.Padding(4);
            this.rent.Name = "rent";
            this.rent.PlaceholderText = "%";
            this.rent.Size = new System.Drawing.Size(135, 24);
            this.rent.TabIndex = 101;
            this.rent.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // travel
            // 
            this.travel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.travel.Location = new System.Drawing.Point(169, 123);
            this.travel.Margin = new System.Windows.Forms.Padding(4);
            this.travel.Name = "travel";
            this.travel.PlaceholderText = "%";
            this.travel.Size = new System.Drawing.Size(135, 24);
            this.travel.TabIndex = 100;
            this.travel.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // basic
            // 
            this.basic.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.basic.Location = new System.Drawing.Point(169, 86);
            this.basic.Margin = new System.Windows.Forms.Padding(4);
            this.basic.Name = "basic";
            this.basic.Size = new System.Drawing.Size(135, 24);
            this.basic.TabIndex = 99;
            this.basic.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // basicSalary
            // 
            this.basicSalary.AutoSize = true;
            this.basicSalary.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.basicSalary.ForeColor = System.Drawing.Color.DarkOrange;
            this.basicSalary.Location = new System.Drawing.Point(58, 89);
            this.basicSalary.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.basicSalary.Name = "basicSalary";
            this.basicSalary.Size = new System.Drawing.Size(112, 18);
            this.basicSalary.TabIndex = 98;
            this.basicSalary.Text = "Basic Salary :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label2.ForeColor = System.Drawing.Color.DarkOrange;
            this.label2.Location = new System.Drawing.Point(43, 51);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(126, 18);
            this.label2.TabIndex = 97;
            this.label2.Text = "Post Category :";
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // Z_AddCategory
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(728, 458);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.postCategory);
            this.Controls.Add(this.travelfds);
            this.Controls.Add(this.totalA);
            this.Controls.Add(this.bo);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.save);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.total);
            this.Controls.Add(this.medical);
            this.Controls.Add(this.other);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.bonus);
            this.Controls.Add(this.medi);
            this.Controls.Add(this.rent);
            this.Controls.Add(this.travel);
            this.Controls.Add(this.basic);
            this.Controls.Add(this.basicSalary);
            this.Controls.Add(this.label2);
            this.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Name = "Z_AddCategory";
            this.Text = "Z_AddCategory";
            this.Load += new System.EventHandler(this.Z_AddCategory_Load);
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox postCategory;
        private System.Windows.Forms.Label travelfds;
        private System.Windows.Forms.TextBox totalA;
        private System.Windows.Forms.Label bo;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button save;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label total;
        private System.Windows.Forms.TextBox medical;
        private System.Windows.Forms.TextBox other;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox bonus;
        private System.Windows.Forms.Label medi;
        private System.Windows.Forms.TextBox rent;
        private System.Windows.Forms.TextBox travel;
        private System.Windows.Forms.TextBox basic;
        private System.Windows.Forms.Label basicSalary;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ErrorProvider errorProvider1;
    }
}