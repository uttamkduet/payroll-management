﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace PayRollSystem
{
    public partial class Z_PasswordChange : Form
    {
        public Z_PasswordChange()
        {
            InitializeComponent();
        }

        private void Z_PasswordChange_Load(object sender, EventArgs e)
        {

        }

        private void change_Click(object sender, EventArgs e)//change password
        {
            if (oldPass.Text == "" || newPass1.Text == "" || newPass2.Text == "")
            {
                errorMsg.Text = "Field Must be not Empty";
            }
            else if (newPass1.Text != newPass2.Text)
            {
                errorMsg.Text = "New Password does not match!";
            }
            else
            {
                adminGateway gatewayAdmin = new adminGateway();
                if (gatewayAdmin.ChangePassword(oldPass.Text, newPass1.Text))
                {
                    errorMsg.Text = "successfully Change Password!";
                }
                else
                {
                    errorMsg.Text = "Old password does not match!";
                }

            }
        }

        private void addCategory_Click(object sender, EventArgs e)
        {
            Z_AddCategory categoryAdd = new Z_AddCategory();
            categoryAdd.Show();
            this.Dispose();
            this.Hide();
        }

        private void addempolyee_Click(object sender, EventArgs e)
        {
            Z_add_employe employeeADD = new Z_add_employe();
            employeeADD.Show();
            this.Dispose();
            this.Hide();
        }

        private void salaryReport_Click(object sender, EventArgs e)
        {
            Z_Payroll newAddpay = new Z_Payroll();
            newAddpay.Show();
            this.Dispose();
            this.Hide();
        }

        private void salary_Click(object sender, EventArgs e)
        {
            Z_MonthlySalary salary = new Z_MonthlySalary();
            salary.Show();
            this.Dispose();
            this.Hide();
        }

        private void changePass_Click(object sender, EventArgs e)
        {
            Z_PasswordChange change = new Z_PasswordChange();
            change.Show();
            this.Dispose();
            this.Hide();
        }

        private void logout_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void monthlyReport_Click(object sender, EventArgs e)
        {
            Z_Payslip pay = new Z_Payslip();
            pay.Show();
            this.Dispose();
            this.Hide();
        }

        private void home_Click(object sender, EventArgs e)
        {
            Z_Dashboard dash = new Z_Dashboard();
            dash.Show();
            this.Dispose();
            this.Hide();
        }
    }
}
