﻿
namespace PayRollSystem
{
    partial class Z_PrintView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Z_PrintView));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.date = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label16 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.label17 = new System.Windows.Forms.Label();
            this.empcode = new System.Windows.Forms.Label();
            this.catPost = new System.Windows.Forms.Label();
            this.presentDay = new System.Windows.Forms.Label();
            this.method = new System.Windows.Forms.Label();
            this.name = new System.Windows.Forms.Label();
            this.basicSalay = new System.Windows.Forms.Label();
            this.working = new System.Windows.Forms.Label();
            this.salary = new System.Windows.Forms.Label();
            this.medi = new System.Windows.Forms.Label();
            this.rent = new System.Windows.Forms.Label();
            this.travel = new System.Windows.Forms.Label();
            this.bonus = new System.Windows.Forms.Label();
            this.other = new System.Windows.Forms.Label();
            this.total = new System.Windows.Forms.Label();
            this.month = new System.Windows.Forms.Label();
            this.printPreviewDialog1 = new System.Windows.Forms.PrintPreviewDialog();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.Window;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.ForeColor = System.Drawing.Color.Coral;
            this.label1.Location = new System.Drawing.Point(192, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(385, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "RETURNONE PRIVATE COMPANY LIMITED";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label2.ForeColor = System.Drawing.Color.LightSlateGray;
            this.label2.Location = new System.Drawing.Point(43, 128);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(117, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "Employee Code:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label3.ForeColor = System.Drawing.Color.LightSlateGray;
            this.label3.Location = new System.Drawing.Point(265, 128);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(56, 20);
            this.label3.TabIndex = 2;
            this.label3.Text = "Name :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label4.ForeColor = System.Drawing.Color.LightSlateGray;
            this.label4.Location = new System.Drawing.Point(43, 200);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(134, 20);
            this.label4.TabIndex = 3;
            this.label4.Text = "Total Working Day:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label5.ForeColor = System.Drawing.Color.LightSlateGray;
            this.label5.Location = new System.Drawing.Point(43, 163);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(68, 20);
            this.label5.TabIndex = 4;
            this.label5.Text = "Position :";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label6.ForeColor = System.Drawing.Color.LightSlateGray;
            this.label6.Location = new System.Drawing.Point(255, 200);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(137, 20);
            this.label6.TabIndex = 5;
            this.label6.Text = "Total Present Days :";
            // 
            // date
            // 
            this.date.AutoSize = true;
            this.date.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.date.ForeColor = System.Drawing.Color.Navy;
            this.date.Location = new System.Drawing.Point(505, 90);
            this.date.Name = "date";
            this.date.Size = new System.Drawing.Size(80, 20);
            this.date.TabIndex = 6;
            this.date.Text = "Bill Month:";
            this.date.Click += new System.EventHandler(this.label7_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label8.ForeColor = System.Drawing.Color.LightSlateGray;
            this.label8.Location = new System.Drawing.Point(255, 163);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(94, 20);
            this.label8.TabIndex = 7;
            this.label8.Text = "Basic Salary :";
            this.label8.Click += new System.EventHandler(this.label8_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label9.ForeColor = System.Drawing.Color.LightSlateGray;
            this.label9.Location = new System.Drawing.Point(506, 130);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(52, 20);
            this.label9.TabIndex = 8;
            this.label9.Text = "Salary:";
            this.label9.Click += new System.EventHandler(this.label9_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label10.ForeColor = System.Drawing.Color.LightSlateGray;
            this.label10.Location = new System.Drawing.Point(506, 189);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(124, 20);
            this.label10.TabIndex = 9;
            this.label10.Text = "Rent Allowamce :";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label11.ForeColor = System.Drawing.Color.LightSlateGray;
            this.label11.Location = new System.Drawing.Point(506, 161);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(142, 20);
            this.label11.TabIndex = 10;
            this.label11.Text = "Medical Allowance :";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label12.ForeColor = System.Drawing.Color.LightSlateGray;
            this.label12.Location = new System.Drawing.Point(506, 216);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(128, 20);
            this.label12.TabIndex = 11;
            this.label12.Text = "Travel Allowance :";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label13.ForeColor = System.Drawing.Color.LightSlateGray;
            this.label13.Location = new System.Drawing.Point(506, 244);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(56, 20);
            this.label13.TabIndex = 12;
            this.label13.Text = "Bonus :";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label14.ForeColor = System.Drawing.Color.LightSlateGray;
            this.label14.Location = new System.Drawing.Point(506, 273);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(59, 20);
            this.label14.TabIndex = 13;
            this.label14.Text = "Others :";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label15.ForeColor = System.Drawing.Color.LightSlateGray;
            this.label15.Location = new System.Drawing.Point(516, 303);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(49, 20);
            this.label15.TabIndex = 14;
            this.label15.Text = "Total: ";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.panel1.Location = new System.Drawing.Point(423, 294);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(300, 1);
            this.panel1.TabIndex = 15;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label16.ForeColor = System.Drawing.Color.LightSlateGray;
            this.label16.Location = new System.Drawing.Point(32, 255);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(128, 20);
            this.label16.TabIndex = 16;
            this.label16.Text = "Payment Method :";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.PaleGreen;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Location = new System.Drawing.Point(293, 351);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(99, 34);
            this.button1.TabIndex = 17;
            this.button1.Text = "Print";
            this.button1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label17.ForeColor = System.Drawing.Color.LightSlateGray;
            this.label17.Location = new System.Drawing.Point(300, 48);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(135, 20);
            this.label17.TabIndex = 18;
            this.label17.Text = "DUET,Gazipur,1707";
            // 
            // empcode
            // 
            this.empcode.AutoSize = true;
            this.empcode.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.empcode.ForeColor = System.Drawing.Color.DarkCyan;
            this.empcode.Location = new System.Drawing.Point(166, 128);
            this.empcode.Name = "empcode";
            this.empcode.Size = new System.Drawing.Size(49, 20);
            this.empcode.TabIndex = 19;
            this.empcode.Text = "12335";
            // 
            // catPost
            // 
            this.catPost.AutoSize = true;
            this.catPost.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.catPost.ForeColor = System.Drawing.Color.DarkCyan;
            this.catPost.Location = new System.Drawing.Point(181, 161);
            this.catPost.Name = "catPost";
            this.catPost.Size = new System.Drawing.Size(49, 20);
            this.catPost.TabIndex = 20;
            this.catPost.Text = "12335";
            // 
            // presentDay
            // 
            this.presentDay.AutoSize = true;
            this.presentDay.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.presentDay.ForeColor = System.Drawing.Color.DarkCyan;
            this.presentDay.Location = new System.Drawing.Point(398, 202);
            this.presentDay.Name = "presentDay";
            this.presentDay.Size = new System.Drawing.Size(49, 20);
            this.presentDay.TabIndex = 21;
            this.presentDay.Text = "12335";
            // 
            // method
            // 
            this.method.AutoSize = true;
            this.method.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.method.ForeColor = System.Drawing.Color.DarkCyan;
            this.method.Location = new System.Drawing.Point(166, 255);
            this.method.Name = "method";
            this.method.Size = new System.Drawing.Size(49, 20);
            this.method.TabIndex = 22;
            this.method.Text = "12335";
            // 
            // name
            // 
            this.name.AutoSize = true;
            this.name.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.name.ForeColor = System.Drawing.Color.DarkCyan;
            this.name.Location = new System.Drawing.Point(367, 128);
            this.name.Name = "name";
            this.name.Size = new System.Drawing.Size(49, 20);
            this.name.TabIndex = 23;
            this.name.Text = "12335";
            // 
            // basicSalay
            // 
            this.basicSalay.AutoSize = true;
            this.basicSalay.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.basicSalay.ForeColor = System.Drawing.Color.DarkCyan;
            this.basicSalay.Location = new System.Drawing.Point(377, 163);
            this.basicSalay.Name = "basicSalay";
            this.basicSalay.Size = new System.Drawing.Size(49, 20);
            this.basicSalay.TabIndex = 24;
            this.basicSalay.Text = "12335";
            // 
            // working
            // 
            this.working.AutoSize = true;
            this.working.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.working.ForeColor = System.Drawing.Color.DarkCyan;
            this.working.Location = new System.Drawing.Point(181, 200);
            this.working.Name = "working";
            this.working.Size = new System.Drawing.Size(49, 20);
            this.working.TabIndex = 25;
            this.working.Text = "12335";
            // 
            // salary
            // 
            this.salary.AutoSize = true;
            this.salary.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.salary.ForeColor = System.Drawing.Color.DarkCyan;
            this.salary.Location = new System.Drawing.Point(654, 128);
            this.salary.Name = "salary";
            this.salary.Size = new System.Drawing.Size(49, 20);
            this.salary.TabIndex = 26;
            this.salary.Text = "12335";
            // 
            // medi
            // 
            this.medi.AutoSize = true;
            this.medi.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.medi.ForeColor = System.Drawing.Color.DarkCyan;
            this.medi.Location = new System.Drawing.Point(654, 162);
            this.medi.Name = "medi";
            this.medi.Size = new System.Drawing.Size(49, 20);
            this.medi.TabIndex = 27;
            this.medi.Text = "12335";
            // 
            // rent
            // 
            this.rent.AutoSize = true;
            this.rent.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.rent.ForeColor = System.Drawing.Color.DarkCyan;
            this.rent.Location = new System.Drawing.Point(654, 189);
            this.rent.Name = "rent";
            this.rent.Size = new System.Drawing.Size(49, 20);
            this.rent.TabIndex = 28;
            this.rent.Text = "12335";
            // 
            // travel
            // 
            this.travel.AutoSize = true;
            this.travel.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.travel.ForeColor = System.Drawing.Color.DarkCyan;
            this.travel.Location = new System.Drawing.Point(654, 216);
            this.travel.Name = "travel";
            this.travel.Size = new System.Drawing.Size(49, 20);
            this.travel.TabIndex = 29;
            this.travel.Text = "12335";
            // 
            // bonus
            // 
            this.bonus.AutoSize = true;
            this.bonus.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.bonus.ForeColor = System.Drawing.Color.DarkCyan;
            this.bonus.Location = new System.Drawing.Point(654, 244);
            this.bonus.Name = "bonus";
            this.bonus.Size = new System.Drawing.Size(49, 20);
            this.bonus.TabIndex = 30;
            this.bonus.Text = "12335";
            // 
            // other
            // 
            this.other.AutoSize = true;
            this.other.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.other.ForeColor = System.Drawing.Color.DarkCyan;
            this.other.Location = new System.Drawing.Point(654, 269);
            this.other.Name = "other";
            this.other.Size = new System.Drawing.Size(49, 20);
            this.other.TabIndex = 31;
            this.other.Text = "12335";
            // 
            // total
            // 
            this.total.AutoSize = true;
            this.total.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.total.ForeColor = System.Drawing.Color.DarkCyan;
            this.total.Location = new System.Drawing.Point(654, 303);
            this.total.Name = "total";
            this.total.Size = new System.Drawing.Size(49, 20);
            this.total.TabIndex = 32;
            this.total.Text = "12335";
            // 
            // month
            // 
            this.month.AutoSize = true;
            this.month.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.month.ForeColor = System.Drawing.Color.LightSlateGray;
            this.month.Location = new System.Drawing.Point(607, 90);
            this.month.Name = "month";
            this.month.Size = new System.Drawing.Size(52, 20);
            this.month.TabIndex = 33;
            this.month.Text = "Salary:";
            // 
            // printPreviewDialog1
            // 
            this.printPreviewDialog1.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.ClientSize = new System.Drawing.Size(400, 300);
            this.printPreviewDialog1.Enabled = true;
            this.printPreviewDialog1.Icon = ((System.Drawing.Icon)(resources.GetObject("printPreviewDialog1.Icon")));
            this.printPreviewDialog1.Name = "printPreviewDialog1";
            this.printPreviewDialog1.Visible = false;
            // 
            // Z_PrintView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(750, 397);
            this.Controls.Add(this.month);
            this.Controls.Add(this.total);
            this.Controls.Add(this.other);
            this.Controls.Add(this.bonus);
            this.Controls.Add(this.travel);
            this.Controls.Add(this.rent);
            this.Controls.Add(this.medi);
            this.Controls.Add(this.salary);
            this.Controls.Add(this.working);
            this.Controls.Add(this.basicSalay);
            this.Controls.Add(this.name);
            this.Controls.Add(this.method);
            this.Controls.Add(this.presentDay);
            this.Controls.Add(this.catPost);
            this.Controls.Add(this.empcode);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.date);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Z_PrintView";
            this.Text = "Print";
            this.Load += new System.EventHandler(this.Z_PrintView_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label date;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label empcode;
        private System.Windows.Forms.Label catPost;
        private System.Windows.Forms.Label presentDay;
        private System.Windows.Forms.Label method;
        private System.Windows.Forms.Label name;
        private System.Windows.Forms.Label basicSalay;
        private System.Windows.Forms.Label working;
        private System.Windows.Forms.Label salary;
        private System.Windows.Forms.Label medi;
        private System.Windows.Forms.Label rent;
        private System.Windows.Forms.Label travel;
        private System.Windows.Forms.Label bonus;
        private System.Windows.Forms.Label other;
        private System.Windows.Forms.Label total;
        private System.Windows.Forms.Label month;
        private System.Windows.Forms.PrintPreviewDialog printPreviewDialog1;
    }
}