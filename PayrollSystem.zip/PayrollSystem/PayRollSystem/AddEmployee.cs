﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Text;

namespace PayRollSystem
{
    class AddEmployee
    {
        private int empid;
        private Int64 employeeCode;
        private int postCategory;

        private string name;
        private string birthDay;
        private string shift;
        private string address;
        private Int64 mobNumber;
        private Int64 accountNumber;
        private string email;
     
        private string status;
        private string password;
        private string hiredDate;
        private string catname;



        public int Empid { get => empid; set => empid = value; }
        public string Name { get => name; set => name = value; }
        public Int64 EmployeeCode { get => employeeCode; set => employeeCode = value; }
        public int PostCategory { get => postCategory; set => postCategory = value; }//from
        public string Catname { get => catname; set => catname = value; }//from
        public string BirthDay { get => birthDay; set => birthDay = value; }
        public string Address { get => address; set => address = value; }
        public Int64 MobNumber { get => mobNumber; set => mobNumber = value; }
        public Int64 AccountNumber { get => accountNumber; set => accountNumber = value; }
        public string Email { get => email; set => email = value; }
        public string Status { get => status; set => status = value; }
        public string Shift1 { get => shift; set => shift = value; }
        public string HiredDate1 { get => hiredDate; set => hiredDate = value; }
        public string Password { get => password; set => password = value; }
       



        //public string Catid2 { get => catid2; set => catid2 = value; }
    }
}
