﻿
namespace PayRollSystem
{
    partial class Z_Dashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Z_Dashboard));
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.logout = new System.Windows.Forms.Button();
            this.changePass = new System.Windows.Forms.Button();
            this.payslip = new System.Windows.Forms.Button();
            this.salaryReport = new System.Windows.Forms.Button();
            this.salary = new System.Windows.Forms.Button();
            this.emprReport = new System.Windows.Forms.Button();
            this.addempolyee = new System.Windows.Forms.Button();
            this.addCategory = new System.Windows.Forms.Button();
            this.home = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.loderPanel = new System.Windows.Forms.Panel();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.panel2.Location = new System.Drawing.Point(181, 115);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(3, 501);
            this.panel2.TabIndex = 99;
            // 
            // panel3
            // 
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.logout);
            this.panel3.Controls.Add(this.changePass);
            this.panel3.Controls.Add(this.payslip);
            this.panel3.Controls.Add(this.salaryReport);
            this.panel3.Controls.Add(this.salary);
            this.panel3.Controls.Add(this.emprReport);
            this.panel3.Controls.Add(this.addempolyee);
            this.panel3.Controls.Add(this.addCategory);
            this.panel3.Controls.Add(this.home);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel3.Location = new System.Drawing.Point(0, 112);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(181, 507);
            this.panel3.TabIndex = 98;
            // 
            // logout
            // 
            this.logout.BackColor = System.Drawing.Color.Transparent;
            this.logout.FlatAppearance.BorderColor = System.Drawing.Color.DeepSkyBlue;
            this.logout.FlatAppearance.BorderSize = 3;
            this.logout.FlatAppearance.MouseDownBackColor = System.Drawing.Color.SandyBrown;
            this.logout.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.logout.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.logout.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.logout.Location = new System.Drawing.Point(2, 340);
            this.logout.Name = "logout";
            this.logout.Size = new System.Drawing.Size(172, 36);
            this.logout.TabIndex = 11;
            this.logout.Text = "Logout";
            this.logout.UseVisualStyleBackColor = false;
            this.logout.Click += new System.EventHandler(this.logout_Click);
            // 
            // changePass
            // 
            this.changePass.BackColor = System.Drawing.Color.Transparent;
            this.changePass.FlatAppearance.BorderColor = System.Drawing.Color.DeepSkyBlue;
            this.changePass.FlatAppearance.BorderSize = 3;
            this.changePass.FlatAppearance.MouseDownBackColor = System.Drawing.Color.SandyBrown;
            this.changePass.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.changePass.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.changePass.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.changePass.Location = new System.Drawing.Point(2, 297);
            this.changePass.Name = "changePass";
            this.changePass.Size = new System.Drawing.Size(172, 36);
            this.changePass.TabIndex = 10;
            this.changePass.Text = "Change Password";
            this.changePass.UseVisualStyleBackColor = false;
            this.changePass.Click += new System.EventHandler(this.changePass_Click);
            // 
            // payslip
            // 
            this.payslip.BackColor = System.Drawing.Color.Transparent;
            this.payslip.FlatAppearance.BorderColor = System.Drawing.Color.DeepSkyBlue;
            this.payslip.FlatAppearance.BorderSize = 3;
            this.payslip.FlatAppearance.MouseDownBackColor = System.Drawing.Color.SandyBrown;
            this.payslip.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.payslip.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.payslip.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.payslip.Location = new System.Drawing.Point(2, 252);
            this.payslip.Name = "payslip";
            this.payslip.Size = new System.Drawing.Size(172, 36);
            this.payslip.TabIndex = 8;
            this.payslip.Text = "Pay Silp";
            this.payslip.UseVisualStyleBackColor = false;
            this.payslip.Click += new System.EventHandler(this.monthlyReport_Click);
            // 
            // salaryReport
            // 
            this.salaryReport.BackColor = System.Drawing.Color.Transparent;
            this.salaryReport.FlatAppearance.BorderColor = System.Drawing.Color.DeepSkyBlue;
            this.salaryReport.FlatAppearance.BorderSize = 3;
            this.salaryReport.FlatAppearance.MouseDownBackColor = System.Drawing.Color.SandyBrown;
            this.salaryReport.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.salaryReport.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.salaryReport.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.salaryReport.Location = new System.Drawing.Point(2, 168);
            this.salaryReport.Name = "salaryReport";
            this.salaryReport.Size = new System.Drawing.Size(172, 36);
            this.salaryReport.TabIndex = 7;
            this.salaryReport.Text = "Payroll";
            this.salaryReport.UseVisualStyleBackColor = false;
            this.salaryReport.Click += new System.EventHandler(this.salaryReport_Click);
            // 
            // salary
            // 
            this.salary.BackColor = System.Drawing.Color.Transparent;
            this.salary.FlatAppearance.BorderColor = System.Drawing.Color.DeepSkyBlue;
            this.salary.FlatAppearance.BorderSize = 3;
            this.salary.FlatAppearance.MouseDownBackColor = System.Drawing.Color.SandyBrown;
            this.salary.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.salary.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.salary.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.salary.Location = new System.Drawing.Point(2, 209);
            this.salary.Name = "salary";
            this.salary.Size = new System.Drawing.Size(172, 36);
            this.salary.TabIndex = 6;
            this.salary.Text = "Monthly Salary";
            this.salary.UseVisualStyleBackColor = false;
            this.salary.Click += new System.EventHandler(this.salary_Click);
            // 
            // emprReport
            // 
            this.emprReport.BackColor = System.Drawing.Color.Transparent;
            this.emprReport.FlatAppearance.BorderColor = System.Drawing.Color.DeepSkyBlue;
            this.emprReport.FlatAppearance.BorderSize = 3;
            this.emprReport.FlatAppearance.MouseDownBackColor = System.Drawing.Color.SandyBrown;
            this.emprReport.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.emprReport.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.emprReport.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.emprReport.Location = new System.Drawing.Point(2, 128);
            this.emprReport.Name = "emprReport";
            this.emprReport.Size = new System.Drawing.Size(172, 34);
            this.emprReport.TabIndex = 5;
            this.emprReport.Text = "Employee Report";
            this.emprReport.UseVisualStyleBackColor = false;
            this.emprReport.Click += new System.EventHandler(this.emprReport_Click);
            // 
            // addempolyee
            // 
            this.addempolyee.BackColor = System.Drawing.Color.Transparent;
            this.addempolyee.FlatAppearance.BorderColor = System.Drawing.Color.DeepSkyBlue;
            this.addempolyee.FlatAppearance.BorderSize = 3;
            this.addempolyee.FlatAppearance.MouseDownBackColor = System.Drawing.Color.SandyBrown;
            this.addempolyee.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.addempolyee.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.addempolyee.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.addempolyee.Location = new System.Drawing.Point(2, 86);
            this.addempolyee.Name = "addempolyee";
            this.addempolyee.Size = new System.Drawing.Size(172, 34);
            this.addempolyee.TabIndex = 4;
            this.addempolyee.Text = "Add Employee";
            this.addempolyee.UseVisualStyleBackColor = false;
            this.addempolyee.Click += new System.EventHandler(this.addempolyee_Click);
            // 
            // addCategory
            // 
            this.addCategory.BackColor = System.Drawing.Color.Transparent;
            this.addCategory.FlatAppearance.BorderColor = System.Drawing.Color.DeepSkyBlue;
            this.addCategory.FlatAppearance.BorderSize = 3;
            this.addCategory.FlatAppearance.MouseDownBackColor = System.Drawing.Color.SandyBrown;
            this.addCategory.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.addCategory.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.addCategory.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.addCategory.Location = new System.Drawing.Point(2, 45);
            this.addCategory.Name = "addCategory";
            this.addCategory.Size = new System.Drawing.Size(172, 34);
            this.addCategory.TabIndex = 3;
            this.addCategory.Text = "Add Category";
            this.addCategory.UseVisualStyleBackColor = false;
            this.addCategory.Click += new System.EventHandler(this.addCategory_Click);
            // 
            // home
            // 
            this.home.BackColor = System.Drawing.Color.Transparent;
            this.home.FlatAppearance.BorderColor = System.Drawing.Color.DeepSkyBlue;
            this.home.FlatAppearance.BorderSize = 3;
            this.home.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.home.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.home.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.home.Location = new System.Drawing.Point(2, 5);
            this.home.Name = "home";
            this.home.Size = new System.Drawing.Size(172, 34);
            this.home.TabIndex = 3;
            this.home.Text = "Dashboard";
            this.home.UseVisualStyleBackColor = false;
            this.home.Click += new System.EventHandler(this.home_Click);
            // 
            // panel1
            // 
            this.panel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel1.BackgroundImage")));
            this.panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(906, 112);
            this.panel1.TabIndex = 97;
            // 
            // loderPanel
            // 
            this.loderPanel.BackColor = System.Drawing.SystemColors.ControlDark;
            this.loderPanel.Location = new System.Drawing.Point(188, 115);
            this.loderPanel.Name = "loderPanel";
            this.loderPanel.Size = new System.Drawing.Size(720, 501);
            this.loderPanel.TabIndex = 100;
            // 
            // Z_Dashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(906, 619);
            this.Controls.Add(this.loderPanel);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Name = "Z_Dashboard";
            this.Text = "Dashboard";
            this.Load += new System.EventHandler(this.Z_Dashboard_Load);
            this.panel3.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button logout;
        private System.Windows.Forms.Button changePass;
        private System.Windows.Forms.Button payslip;
        private System.Windows.Forms.Button salaryReport;
        private System.Windows.Forms.Button salary;
        private System.Windows.Forms.Button emprReport;
        private System.Windows.Forms.Button addempolyee;
        private System.Windows.Forms.Button addCategory;
        private System.Windows.Forms.Button home;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel loderPanel;
    }
}