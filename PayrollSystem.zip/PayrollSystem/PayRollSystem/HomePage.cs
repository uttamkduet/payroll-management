﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace PayRollSystem
{
    public partial class HomePage : Form
    {
        public HomePage()
        {
           InitializeComponent();
            home_uc1.Show();
            home_uc1.BringToFront();


        }

        private void button1_Click(object sender, EventArgs e)
        {
            Z_add_employe newAddEmplye = new Z_add_employe();
            newAddEmplye.Show();
            this.Dispose();
            this.Hide();

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {




        }

        private void addCategory_uc2_Load(object sender, EventArgs e)
        {

        }

        private void panel7_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel6_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel5_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void panel8_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel9_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel10_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel4_Paint(object sender, PaintEventArgs e)
        {

        }

        private void addempolyee_Click(object sender, EventArgs e)
        {
            /*try
            {
                add_empy_details_uc1.Show();
                add_empy_details_uc1.BringToFront();
            }
            catch { }*/

            Z_add_employe newAddEmplye = new Z_add_employe();
            newAddEmplye.Show();
            this.Dispose();
            this.Hide();



        }

        private void logout_Click(object sender, EventArgs e)
        {
           
        }

        private void userControl11_Load(object sender, EventArgs e)
        {

        }

        private void HomePage_Load(object sender, EventArgs e)
        {

        }

        private void home_Click(object sender, EventArgs e)
        {   
            home_uc1.Show();
            home_uc1.BringToFront();
        }

        private void emprReport_Click(object sender, EventArgs e)
        {
            //emplyee_report1.Show();
            //emplyee_report1.BringToFront();

        }

        private void salaryReport_Click(object sender, EventArgs e)
        {
            Z_Payroll newAddpay = new Z_Payroll();
            newAddpay.Show();
            this.Dispose();
            this.Hide();
        }

        private void salary_Click(object sender, EventArgs e)
        {
            Z_MonthlySalary salary = new Z_MonthlySalary();
            salary.Show();
            this.Dispose();
            this.Hide();

        }

        private void monthlyReport_Click(object sender, EventArgs e)
        {

        }

        private void changePass_Click(object sender, EventArgs e)
        {
            Z_PasswordChange change = new Z_PasswordChange();
            change.Show();
            this.Dispose();
            this.Hide();
        }

        private void home_uc1_Load(object sender, EventArgs e)
        {

        }
    }
}
