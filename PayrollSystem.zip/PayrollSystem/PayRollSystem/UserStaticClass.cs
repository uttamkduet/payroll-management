﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PayRollSystem
{
    public static class  UserStaticClass
    {

        static Int32 empcode;
        static string userPass;

        public static string UserPass { get => userPass; set => userPass = value; }
        public static int Empcode { get => empcode; set => empcode = value; }
    }
}
