﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace PayRollSystem
{
    public partial class Z_UserProfile : Form
    {
        public Z_UserProfile()
        {
            InitializeComponent();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void Z_UserProfile_Load(object sender, EventArgs e)
        {
            List<string> Stringlist = new List<string>();
            UserGateway gatewaUser = new UserGateway();
            Stringlist = gatewaUser.UserProfile();
            empCode.Text = Stringlist[0];
            name1.Text = Stringlist[1];
            post1.Text = Stringlist[5];
            email.Text = Stringlist[4];
            shift.Text = Stringlist[3];
            string ss = Stringlist[2];
            birth.Text =  ss.Substring(0,9);
        }
    }
}
