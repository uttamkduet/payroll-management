﻿
namespace PayRollSystem
{
    partial class Z_Payroll
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.others = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.cash = new System.Windows.Forms.RadioButton();
            this.online = new System.Windows.Forms.RadioButton();
            this.label4 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.total = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.totalwork = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.salaryI = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.presentDays = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.month = new System.Windows.Forms.DateTimePicker();
            this.bouns = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.rent = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.medi = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.travel = new System.Windows.Forms.TextBox();
            this.laves = new System.Windows.Forms.Label();
            this.basic = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.account = new System.Windows.Forms.TextBox();
            this.empcategory = new System.Windows.Forms.TextBox();
            this.empname = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.empcode = new System.Windows.Forms.TextBox();
            this.empyCode = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.panel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // others
            // 
            this.others.Location = new System.Drawing.Point(534, 319);
            this.others.Margin = new System.Windows.Forms.Padding(4);
            this.others.Name = "others";
            this.others.Size = new System.Drawing.Size(135, 27);
            this.others.TabIndex = 147;
            this.others.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label3.ForeColor = System.Drawing.Color.DarkOrange;
            this.label3.Location = new System.Drawing.Point(456, 322);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(69, 18);
            this.label3.TabIndex = 146;
            this.label3.Text = "Others :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label5.ForeColor = System.Drawing.Color.LimeGreen;
            this.label5.Location = new System.Drawing.Point(50, 454);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(139, 18);
            this.label5.TabIndex = 145;
            this.label5.Text = "Payment Method:";
            // 
            // cash
            // 
            this.cash.AutoSize = true;
            this.cash.Location = new System.Drawing.Point(196, 454);
            this.cash.Name = "cash";
            this.cash.Size = new System.Drawing.Size(58, 24);
            this.cash.TabIndex = 144;
            this.cash.TabStop = true;
            this.cash.Text = "Cash";
            this.cash.UseVisualStyleBackColor = true;
            // 
            // online
            // 
            this.online.AutoSize = true;
            this.online.Location = new System.Drawing.Point(276, 455);
            this.online.Name = "online";
            this.online.Size = new System.Drawing.Size(127, 24);
            this.online.TabIndex = 143;
            this.online.TabStop = true;
            this.online.Text = "Online Banking";
            this.online.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label4.ForeColor = System.Drawing.Color.DarkOrange;
            this.label4.Location = new System.Drawing.Point(42, 162);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(138, 18);
            this.label4.TabIndex = 142;
            this.label4.Text = "Account Number:";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label15.ForeColor = System.Drawing.Color.DarkOrange;
            this.label15.Location = new System.Drawing.Point(54, 133);
            this.label15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(126, 18);
            this.label15.TabIndex = 141;
            this.label15.Text = "Post Category :";
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.ForestGreen;
            this.button3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button3.FlatAppearance.BorderColor = System.Drawing.Color.Green;
            this.button3.FlatAppearance.BorderSize = 2;
            this.button3.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Chocolate;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.button3.ForeColor = System.Drawing.Color.White;
            this.button3.Location = new System.Drawing.Point(561, 449);
            this.button3.Margin = new System.Windows.Forms.Padding(4);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(108, 36);
            this.button3.TabIndex = 140;
            this.button3.Text = "POST";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // total
            // 
            this.total.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.total.ForeColor = System.Drawing.Color.Red;
            this.total.Location = new System.Drawing.Point(317, 396);
            this.total.Margin = new System.Windows.Forms.Padding(4);
            this.total.Name = "total";
            this.total.ReadOnly = true;
            this.total.Size = new System.Drawing.Size(214, 24);
            this.total.TabIndex = 139;
            this.total.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label14.ForeColor = System.Drawing.Color.Crimson;
            this.label14.Location = new System.Drawing.Point(197, 398);
            this.label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(118, 18);
            this.label14.TabIndex = 138;
            this.label14.Text = "Total Amount :";
            // 
            // totalwork
            // 
            this.totalwork.Location = new System.Drawing.Point(185, 218);
            this.totalwork.Margin = new System.Windows.Forms.Padding(4);
            this.totalwork.Name = "totalwork";
            this.totalwork.Size = new System.Drawing.Size(135, 27);
            this.totalwork.TabIndex = 137;
            this.totalwork.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.totalwork.TextChanged += new System.EventHandler(this.totalwork_TextChanged);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label13.ForeColor = System.Drawing.Color.DarkOrange;
            this.label13.Location = new System.Drawing.Point(22, 218);
            this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(167, 18);
            this.label13.TabIndex = 136;
            this.label13.Text = "Total Working Days :";
            // 
            // salaryI
            // 
            this.salaryI.Location = new System.Drawing.Point(184, 321);
            this.salaryI.Margin = new System.Windows.Forms.Padding(4);
            this.salaryI.Name = "salaryI";
            this.salaryI.ReadOnly = true;
            this.salaryI.Size = new System.Drawing.Size(135, 27);
            this.salaryI.TabIndex = 135;
            this.salaryI.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label12.ForeColor = System.Drawing.Color.DarkOrange;
            this.label12.Location = new System.Drawing.Point(114, 325);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(65, 18);
            this.label12.TabIndex = 134;
            this.label12.Text = "Salary :";
            // 
            // presentDays
            // 
            this.presentDays.Location = new System.Drawing.Point(185, 284);
            this.presentDays.Margin = new System.Windows.Forms.Padding(4);
            this.presentDays.Name = "presentDays";
            this.presentDays.ReadOnly = true;
            this.presentDays.Size = new System.Drawing.Size(135, 27);
            this.presentDays.TabIndex = 133;
            this.presentDays.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label11.ForeColor = System.Drawing.Color.DarkOrange;
            this.label11.Location = new System.Drawing.Point(69, 288);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(119, 18);
            this.label11.TabIndex = 132;
            this.label11.Text = "Present Days :";
            // 
            // month
            // 
            this.month.Location = new System.Drawing.Point(469, 182);
            this.month.Name = "month";
            this.month.Size = new System.Drawing.Size(200, 27);
            this.month.TabIndex = 131;
            // 
            // bouns
            // 
            this.bouns.Location = new System.Drawing.Point(534, 284);
            this.bouns.Margin = new System.Windows.Forms.Padding(4);
            this.bouns.Name = "bouns";
            this.bouns.ReadOnly = true;
            this.bouns.Size = new System.Drawing.Size(135, 27);
            this.bouns.TabIndex = 130;
            this.bouns.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label9.ForeColor = System.Drawing.Color.DarkOrange;
            this.label9.Location = new System.Drawing.Point(456, 287);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(75, 18);
            this.label9.TabIndex = 129;
            this.label9.Text = "Bounus :";
            // 
            // rent
            // 
            this.rent.Location = new System.Drawing.Point(534, 252);
            this.rent.Margin = new System.Windows.Forms.Padding(4);
            this.rent.Name = "rent";
            this.rent.ReadOnly = true;
            this.rent.Size = new System.Drawing.Size(135, 27);
            this.rent.TabIndex = 128;
            this.rent.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label7.ForeColor = System.Drawing.Color.DarkOrange;
            this.label7.Location = new System.Drawing.Point(390, 257);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(134, 18);
            this.label7.TabIndex = 127;
            this.label7.Text = "Rent Allowance :";
            // 
            // medi
            // 
            this.medi.Location = new System.Drawing.Point(532, 218);
            this.medi.Margin = new System.Windows.Forms.Padding(4);
            this.medi.Name = "medi";
            this.medi.ReadOnly = true;
            this.medi.Size = new System.Drawing.Size(135, 27);
            this.medi.TabIndex = 126;
            this.medi.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label6.ForeColor = System.Drawing.Color.DarkOrange;
            this.label6.Location = new System.Drawing.Point(365, 219);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(157, 18);
            this.label6.TabIndex = 125;
            this.label6.Text = "Medical Allowance :";
            // 
            // travel
            // 
            this.travel.Location = new System.Drawing.Point(183, 354);
            this.travel.Margin = new System.Windows.Forms.Padding(4);
            this.travel.Name = "travel";
            this.travel.ReadOnly = true;
            this.travel.Size = new System.Drawing.Size(135, 27);
            this.travel.TabIndex = 124;
            this.travel.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // laves
            // 
            this.laves.AutoSize = true;
            this.laves.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.laves.ForeColor = System.Drawing.Color.DarkOrange;
            this.laves.Location = new System.Drawing.Point(30, 357);
            this.laves.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.laves.Name = "laves";
            this.laves.Size = new System.Drawing.Size(145, 18);
            this.laves.TabIndex = 123;
            this.laves.Text = "Travel Allowance :";
            // 
            // basic
            // 
            this.basic.Location = new System.Drawing.Point(185, 250);
            this.basic.Margin = new System.Windows.Forms.Padding(4);
            this.basic.Name = "basic";
            this.basic.ReadOnly = true;
            this.basic.Size = new System.Drawing.Size(135, 27);
            this.basic.TabIndex = 122;
            this.basic.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label10.ForeColor = System.Drawing.Color.DarkOrange;
            this.label10.Location = new System.Drawing.Point(72, 252);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(112, 18);
            this.label10.TabIndex = 121;
            this.label10.Text = "Basic Salary :";
            // 
            // account
            // 
            this.account.Location = new System.Drawing.Point(183, 159);
            this.account.Margin = new System.Windows.Forms.Padding(4);
            this.account.Multiline = true;
            this.account.Name = "account";
            this.account.ReadOnly = true;
            this.account.Size = new System.Drawing.Size(173, 24);
            this.account.TabIndex = 120;
            // 
            // empcategory
            // 
            this.empcategory.Location = new System.Drawing.Point(183, 129);
            this.empcategory.Margin = new System.Windows.Forms.Padding(4);
            this.empcategory.Multiline = true;
            this.empcategory.Name = "empcategory";
            this.empcategory.ReadOnly = true;
            this.empcategory.Size = new System.Drawing.Size(173, 24);
            this.empcategory.TabIndex = 119;
            // 
            // empname
            // 
            this.empname.Location = new System.Drawing.Point(183, 100);
            this.empname.Margin = new System.Windows.Forms.Padding(4);
            this.empname.Multiline = true;
            this.empname.Name = "empname";
            this.empname.ReadOnly = true;
            this.empname.Size = new System.Drawing.Size(173, 24);
            this.empname.TabIndex = 118;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label2.ForeColor = System.Drawing.Color.DarkOrange;
            this.label2.Location = new System.Drawing.Point(39, 101);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(136, 18);
            this.label2.TabIndex = 117;
            this.label2.Text = "Employee Name:";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Transparent;
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.FlatAppearance.BorderColor = System.Drawing.Color.Green;
            this.button1.FlatAppearance.BorderSize = 2;
            this.button1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Chocolate;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.button1.ForeColor = System.Drawing.Color.Green;
            this.button1.Location = new System.Drawing.Point(386, 62);
            this.button1.Margin = new System.Windows.Forms.Padding(4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(97, 32);
            this.button1.TabIndex = 116;
            this.button1.Text = "Search";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // empcode
            // 
            this.empcode.Location = new System.Drawing.Point(183, 66);
            this.empcode.Margin = new System.Windows.Forms.Padding(4);
            this.empcode.Multiline = true;
            this.empcode.Name = "empcode";
            this.empcode.Size = new System.Drawing.Size(173, 24);
            this.empcode.TabIndex = 115;
            // 
            // empyCode
            // 
            this.empyCode.AutoSize = true;
            this.empyCode.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.empyCode.ForeColor = System.Drawing.Color.DarkOrange;
            this.empyCode.Location = new System.Drawing.Point(50, 72);
            this.empyCode.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.empyCode.Name = "empyCode";
            this.empyCode.Size = new System.Drawing.Size(137, 18);
            this.empyCode.TabIndex = 114;
            this.empyCode.Text = "Employee Code :";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.panel4.Controls.Add(this.label1);
            this.panel4.Location = new System.Drawing.Point(209, 4);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(256, 35);
            this.panel4.TabIndex = 113;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(82, 6);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(73, 24);
            this.label1.TabIndex = 21;
            this.label1.Text = "Payroll";
            // 
            // Z_Payroll
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(736, 498);
            this.Controls.Add(this.others);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.cash);
            this.Controls.Add(this.online);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.total);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.totalwork);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.salaryI);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.presentDays);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.month);
            this.Controls.Add(this.bouns);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.rent);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.medi);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.travel);
            this.Controls.Add(this.laves);
            this.Controls.Add(this.basic);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.account);
            this.Controls.Add(this.empcategory);
            this.Controls.Add(this.empname);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.empcode);
            this.Controls.Add(this.empyCode);
            this.Controls.Add(this.panel4);
            this.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Name = "Z_Payroll";
            this.Text = "Payroll";
            this.Load += new System.EventHandler(this.Z_Payroll_Load);
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox others;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.RadioButton cash;
        private System.Windows.Forms.RadioButton online;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.TextBox total;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox totalwork;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox salaryI;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox presentDays;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.DateTimePicker month;
        private System.Windows.Forms.TextBox bouns;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox rent;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox medi;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox travel;
        private System.Windows.Forms.Label laves;
        private System.Windows.Forms.TextBox basic;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox account;
        private System.Windows.Forms.TextBox empcategory;
        private System.Windows.Forms.TextBox empname;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox empcode;
        private System.Windows.Forms.Label empyCode;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label1;
    }
}