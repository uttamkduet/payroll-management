﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;

namespace PayRollSystem
{
    class addEmlyGateway
    {
        DBConnector connetor = null;
        SqlConnection connnection = null;
        List<AddEmployee> addempyList = null;
        AddEmployee addempyee = null;



        public addEmlyGateway()
        {
            connetor = new DBConnector();
            connnection = connetor.Connection;
        }

        

       


        public Boolean intsertData(AddEmployee EmployeeAdd)
        {

            try {
                connnection.Open();
                string insertQuery = "INSERT INTO employee(name,dateTime,postCategory,shift,address,mobNumber,account,email,status,password,hired,eplyeeCode)" +
                    "VALUES('" + EmployeeAdd.Name + "','" + EmployeeAdd.BirthDay + "','" + EmployeeAdd.PostCategory + "','" + EmployeeAdd.Shift1 + "','" + EmployeeAdd.Address + "','" + EmployeeAdd.MobNumber + "','" + EmployeeAdd.AccountNumber + "','" + EmployeeAdd.Email + "','" + EmployeeAdd.Status + "','" + EmployeeAdd.Password + "','" + EmployeeAdd.HiredDate1 + "','" + EmployeeAdd.EmployeeCode + "')";
                SqlCommand command = new SqlCommand(insertQuery, connnection);
                command.ExecuteNonQuery();
                connnection.Close();
                return true;
            } catch { return false; }
        }

        public List<AddEmployee> GetData()
        {
            connnection.Open();
            addempyList = new List<AddEmployee>();
         
            
            string selectQuery = "SELECT employee.empid,employee.name,employee.eplyeeCode,employee.dateTime,employee.address,employee.mobNumber,employee.account,employee.email,employee.status, employee.shift,employee.hired,category.catname,category.catid FROM employee INNER JOIN category ON " +
                "employee.postCategory = category.catid ";
            //try {
                SqlCommand command = new SqlCommand(selectQuery, connnection);
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    addempyee = new AddEmployee();

                    addempyee.Empid = Convert.ToInt32(reader["empid"]);
                    addempyee.Name = reader["name"].ToString();
                    addempyee.EmployeeCode = Convert.ToInt32(reader["eplyeeCode"]);
                    addempyee.PostCategory = Convert.ToInt32(reader["catid"]);//from categroy table
                    addempyee.Catname = reader["catname"].ToString();      //from categroy table                                // addempyee.Catname = reader["catname"].ToString();//from categroy table

                    addempyee.BirthDay = reader["dateTime"].ToString();
                    addempyee.Address = reader["address"].ToString();
                    addempyee.MobNumber = Convert.ToInt32(reader["mobNumber"]);
                    addempyee.AccountNumber = Convert.ToInt32(reader["account"]);
                    addempyee.Email = reader["email"].ToString();
                     addempyee.Status = reader["status"].ToString();
                    addempyee.Shift1 = reader["shift"].ToString();
                    addempyee.HiredDate1 = reader["hired"].ToString();

                    addempyList.Add(addempyee);
                }
                return addempyList;
          /*  } catch {
                return addempyList;
            }*/

        }

        public void updateData(AddEmployee EmployeeAdd)
        {
            connnection.Open();
            
            string updateQuery = "UPDATE employee SET " +
             "name = '" + EmployeeAdd.Name + "'," +
              "postCategory = '" + EmployeeAdd.PostCategory + "'," +
              "dateTime = '" + EmployeeAdd.BirthDay + "'," +
             "shift = '" + EmployeeAdd.Shift1 + "'," +
              "address = '" + EmployeeAdd.Address + "'," +
              "mobNumber = '" + EmployeeAdd.MobNumber + "'," +
              "account = '" + EmployeeAdd.AccountNumber + "'," +
              "email = '" + EmployeeAdd.Email + "'," +
              "status = '" + EmployeeAdd.Status + "'," +
             "hired = '" + EmployeeAdd.HiredDate1 + "' WHERE empid = '" + EmployeeAdd.Empid + "'";

            SqlCommand command = new SqlCommand(updateQuery, connnection);
            command.ExecuteNonQuery();
            connnection.Close();
        }

        public void DeleteById(AddEmployee EmployeeAdd)
        {
            connnection.Open();
            string updateQuery = "DELETE FROM employee WHERE empid = '" + EmployeeAdd.Empid + "'";

            SqlCommand command = new SqlCommand(updateQuery, connnection);
            command.ExecuteNonQuery();
            connnection.Close();
        }





    }
}
