﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace PayRollSystem
{
    public partial class add_empy_details_UC : UserControl
    {


        AddEmployee EmployeeAdd = null;
        addEmlyGateway GatewayaddEmployee = null;
        CategoryGateway categoryGateway = null;
        List<AddEmployee> EpolyeeList = null;
        int emlyid = 0;


        public add_empy_details_UC()
        {
            InitializeComponent();
            loadviewList();

        }
        private void loadviewList()
        {
            //grid view
            addEmlyGateway GatewayaddEmployee = new addEmlyGateway();
            List<AddEmployee> EpolyeeList = new List<AddEmployee>();
            EpolyeeList = GatewayaddEmployee.GetData();
            dataGridView1.DataSource = EpolyeeList;

            this.dataGridView1.Columns["Empid"].Visible = false;
            this.dataGridView1.Columns["PostCategory"].Visible = false;
            this.dataGridView1.Columns["Password"].Visible = false;
        }

        private void shift_combobox()
        {
            List<z_shiftComboBox> list = new List<z_shiftComboBox>();
            list.Add(new z_shiftComboBox() { Value = "Day", Name = "Day" });
            list.Add(new z_shiftComboBox() { Value = "Night", Name = "Night" });
            shift.DataSource = list;
            shift.ValueMember = "Value";
            shift.DisplayMember = "Name";
            shift.SelectedIndex = 0;
        }

        private void add_empy_details_UC_Load(object sender, EventArgs e)
        {


            shift_combobox();



            status.DisplayMember = "Text";
            status.ValueMember = "Value";
            status.Items.Add(new { Text = "Active", Value = "1" });
            status.Items.Add(new { Text = "inactive", Value = "0" });
            ////end



            //Show category list in combobox
            BindingList<test> _comboItems = new BindingList<test>();
            CategoryGateway categoryGateway = new CategoryGateway();
            _comboItems = categoryGateway.GetAllData2();
            postCategory.ValueMember = "Catid";
            postCategory.DisplayMember = "Catname";
            postCategory.DataSource = _comboItems;


        }


        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void postCategory_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private Boolean Validation()
        {
            bool flag = true;
            string msg = "";
            if (employeeCode.Text == "")
            {
                msg += "Employee Code must be not Empty!!\n";
                flag = false;
            }
            if (name.Text == "")
            {
                msg += "Name Code must be not Empty!!\n";
                flag = false;
            }
            if (address.Text == "")
            {
                msg += "Adress Code must be not Empty!!\n";
                flag = false;
            }
            if (mobnumber.Text == "")
            {
                msg += "Mobile Number  must be not Empty!!\n";
                flag = false;
            }
            if (account.Text == "")
            {
                msg += "Account  must be not Empty!!\n";
                flag = false;
            }
            if (email.Text == "")
            {
                msg += "Email  must be not Empty!!\n";
                flag = false;
            }
            if (email.Text == "")
            {
                msg += "Account  must be not Empty!!\n";
                flag = false;
            }
            if (password.Text == "")
            {
                msg += "Passward  must be not Empty!!\n";
                flag = false;
            }

            if (flag == false)
            {
                MessageBox.Show(msg, "Empty", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            return true;
        }

        private void button1_Click(object sender, EventArgs e)//save/Insert data
        {
            AddEmployee EmployeeAdd = new AddEmployee();
            addEmlyGateway GatewayaddEmployee = new addEmlyGateway();


            string theDate = birthday.Value.ToShortDateString();
            string theDate2 = hired.Value.ToShortDateString();


            if (Validation())
            {

                EmployeeAdd.Name = name.Text;
                EmployeeAdd.BirthDay = theDate;
                EmployeeAdd.EmployeeCode = int.Parse(employeeCode.Text);

                string test = "0" + postCategory.SelectedValue;
                int postid = Convert.ToInt32(test);

                EmployeeAdd.PostCategory = postid;
                EmployeeAdd.Address = address.Text;
                EmployeeAdd.MobNumber = int.Parse(mobnumber.Text);
                EmployeeAdd.AccountNumber = int.Parse(account.Text);
                EmployeeAdd.Email = email.Text;
                string test1 = "0" + status.GetItemText(status.SelectedItem);
                EmployeeAdd.Status = "dfg";
                EmployeeAdd.Password = password.Text;
                EmployeeAdd.HiredDate1 = theDate2.ToString();
                EmployeeAdd.Shift1 = shift.SelectedValue.ToString();


                GatewayaddEmployee.intsertData(EmployeeAdd);
                loadviewList();
                MessageBox.Show("Inserted Successfull");
            }
        }

        private void shift_SelectedIndexChanged(object sender, EventArgs e)
        {


        }

        private void birthday_ValueChanged(object sender, EventArgs e)
        {

        }
        private void ClearField()
        {
            employeeCode.Clear();
            name.Clear();
            address.Clear();
            mobnumber.Clear();
            account.Clear();
            email.Clear();
            employeeCode.ReadOnly = false;
            password.ReadOnly = false;
            this.emlyid = 0;

        }


        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            employeeCode.Text = dataGridView1.SelectedRows[0].Cells["EmployeeCode"].Value.ToString();
            //or s name.Text =  dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
            name.Text = dataGridView1.SelectedRows[0].Cells["name"].Value.ToString();

            string ss = dataGridView1.SelectedRows[0].Cells["PostCategory"].Value.ToString();
            emlyid = int.Parse(dataGridView1.SelectedRows[0].Cells["Empid"].Value.ToString());
           
            ///selected Category in comboBox
            for (int i = 0; i < postCategory.Items.Count; i++)
            {
                var prop = postCategory.Items[i].GetType().GetProperty(postCategory.ValueMember);
                if (prop != null && prop.GetValue(postCategory.Items[i], null).ToString() == ss)
                {
                    postCategory.SelectedIndex = i;
                    break;
                }
            }

            string date = dataGridView1.SelectedRows[0].Cells[3].Value.ToString();
            // DateTime birthday = Convert.ToDateTime(date);
            address.Text = dataGridView1.SelectedRows[0].Cells["Address"].Value.ToString();
            mobnumber.Text = dataGridView1.SelectedRows[0].Cells["MobNumber"].Value.ToString();
            account.Text = dataGridView1.SelectedRows[0].Cells["AccountNumber"].Value.ToString();
            email.Text = dataGridView1.SelectedRows[0].Cells["Email"].Value.ToString();
            string sshift = dataGridView1.SelectedRows[0].Cells["Shift1"].Value.ToString();

            ///selected Shift in comboBox
            for (int i = 0; i < shift.Items.Count; i++)
            {
                var prop = shift.Items[i].GetType().GetProperty(shift.DisplayMember);
                if (prop != null && prop.GetValue(shift.Items[i], null).ToString() == sshift)
                {
                    shift.SelectedIndex = i;
                    break;
                }
            }


            employeeCode.ReadOnly = true;
            password.ReadOnly = true;
            //status.Text =  dataGridView1.SelectedRows[0].Cells[8].Value.ToString();
            //hired.Text =  dataGridView1.SelectedRows[0].Cells[10].Value.ToString();*/

        }


        private void button2_Click(object sender, EventArgs e)//update employee data
        {
            AddEmployee EmployeeAdd = new AddEmployee();
            addEmlyGateway GatewayaddEmployee = new addEmlyGateway();


            string theDate = birthday.Value.ToShortDateString();
            string theDate2 = hired.Value.ToShortDateString();

            if (this.emlyid > 0)
            {
                if (Validation())
                {
                    EmployeeAdd.Empid = this.emlyid;

                    EmployeeAdd.Name = name.Text;
                    EmployeeAdd.BirthDay = theDate;

                    string test = "0" + postCategory.SelectedValue;
                    int postid = Convert.ToInt32(test);

                    EmployeeAdd.PostCategory = postid;
                    EmployeeAdd.EmployeeCode = int.Parse(employeeCode.Text);
                    EmployeeAdd.Address = address.Text;
                    EmployeeAdd.MobNumber = int.Parse(mobnumber.Text);
                    EmployeeAdd.AccountNumber = int.Parse(account.Text);
                    EmployeeAdd.Email = email.Text;

                    EmployeeAdd.Status = "";
                    EmployeeAdd.Password = password.Text;
                    EmployeeAdd.HiredDate1 = theDate2.ToString();
                    EmployeeAdd.Shift1 = shift.SelectedValue.ToString();


                    GatewayaddEmployee.updateData(EmployeeAdd);
                    loadviewList();
                    MessageBox.Show("Update  Successfull", "Updated", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            else MessageBox.Show("Please Select Item Before Update !!", "Updae??", MessageBoxButtons.OK, MessageBoxIcon.Error);
            
        }

        private void button4_Click(object sender, EventArgs e)///Clear 
        {
            ClearField();
           
        }

        private void delete_Click(object sender, EventArgs e)
        {
            if (this.emlyid > 0)
            {
                DialogResult dialog = MessageBox.Show("Do You Want To Delete Emplyee!!", "Warning!!", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                if (dialog == DialogResult.Yes)
                {
                    AddEmployee EmployeeAdd = new AddEmployee();
                    addEmlyGateway GatewayaddEmployee = new addEmlyGateway();
                    EmployeeAdd.Empid = this.emlyid;
                    GatewayaddEmployee.DeleteById(EmployeeAdd);

                    MessageBox.Show("Delete  Successfull", "Deleted", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    loadviewList();
                    ClearField();

                }
                else if (dialog == DialogResult.No)
                {
                    // e.Cancel = true;
                }
            }
            else
            {
                MessageBox.Show("Please Select Before Delete !!", "Select??", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void search_Click(object sender, EventArgs e)
        {
            
            
                /*GatewayaddEmployee = new addEmlyGateway();
                EpolyeeList = new List<AddEmployee>();
                EpolyeeList = GatewayaddEmployee.GetData();
                dataGridView1.DataSource = EpolyeeList;

                this.dataGridView1.Columns["Empid"].Visible = false;
                this.dataGridView1.Columns["PostCategory"].Visible = false;
                this.dataGridView1.Columns["Password"].Visible = false;*/

                string searchValue = searchField.Text;
                int rowIndex = -1;
                bool flag = true;
                dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
                try
                {
                    foreach (DataGridViewRow row in dataGridView1.Rows)
                    {
                        if (row.Cells["EmployeeCode"].Value.ToString().Contains(searchValue))
                        {
                            rowIndex = row.Index;
                            dataGridView1.ClearSelection();
                            row.Selected = true;
                            dataGridView1.FirstDisplayedScrollingRowIndex = rowIndex;
                            dataGridView1.Focus();
                            flag = false;
                            break;
                        }
                    }
                    if (flag == true) MessageBox.Show("No solutions with that Employee code.");
            }
                catch (Exception)
                {
                    MessageBox.Show("No solutions with that Employee code.");
                }
            
         }

























    }
}
